﻿namespace A10_AutoTestTool
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.skinTabControl_Menu = new CCWin.SkinControl.SkinTabControl();
            this.skinTabPage_PCBA = new CCWin.SkinControl.SkinTabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.skinTabControl_MB = new CCWin.SkinControl.SkinTabControl();
            this.skinTabPage_MB_PCBANum = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer1 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel_PCBANumTip = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_Confirm = new CCWin.SkinControl.SkinButton();
            this.skinLabel_PCBANumStartTip = new CCWin.SkinControl.SkinLabel();
            this.textBox_MB_QRCode = new System.Windows.Forms.TextBox();
            this.skinTabPage_MB_Power = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer2 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel_MB_PowerTimeCountDown = new CCWin.SkinControl.SkinLabel();
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_Power_Success = new CCWin.SkinControl.SkinButton();
            this.skinLabel_MB_POWER_RESULT = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_Power_rTest = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_Power_Over = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_Power_Fail = new CCWin.SkinControl.SkinButton();
            this.skinLabel4 = new CCWin.SkinControl.SkinLabel();
            this.skinTabPage_MB_BT = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer17 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel5 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel_MB_BT_TIME = new CCWin.SkinControl.SkinLabel();
            this.skinLabel50 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel66 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_BT_FAIL = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_BT_SUCCESS = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_BT_RETEST = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_BT_SKIP = new CCWin.SkinControl.SkinButton();
            this.skinLabel_MB_BT_RESULT = new CCWin.SkinControl.SkinLabel();
            this.skinLabel68 = new CCWin.SkinControl.SkinLabel();
            this.skinTabPage_MB_Temp = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer3 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel_MB_TEMP_TIME = new CCWin.SkinControl.SkinLabel();
            this.skinLabel8 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel9 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel_MB_Temp_Result1 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_Temp_rTest = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_Temp_Skip = new CCWin.SkinControl.SkinButton();
            this.skinLabel_MB_Temp_Result = new CCWin.SkinControl.SkinLabel();
            this.skinLabel11 = new CCWin.SkinControl.SkinLabel();
            this.skinTabPage_MB_Lock = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer4 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel_MB_Lock_Time = new CCWin.SkinControl.SkinLabel();
            this.skinLabel7 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel10 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel6 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel_MB_Lock_Result1 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_Lock_rTest = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_Lock_Skip = new CCWin.SkinControl.SkinButton();
            this.skinLabel_MB_Lock_Result = new CCWin.SkinControl.SkinLabel();
            this.skinLabel14 = new CCWin.SkinControl.SkinLabel();
            this.skinTabPage_MB_PowerDown = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer5 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel12 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel_MB_PowerDown_Time = new CCWin.SkinControl.SkinLabel();
            this.skinLabel16 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel17 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_PowerDown_Fail = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_PowerDown_Success = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_PowerDown_rTest = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_PowerDown_Skip = new CCWin.SkinControl.SkinButton();
            this.skinLabel_MB_PowerDown_Result = new CCWin.SkinControl.SkinLabel();
            this.skinLabel19 = new CCWin.SkinControl.SkinLabel();
            this.skinTabPage_MB_Battery = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer6 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel_MB_Battery_Time = new CCWin.SkinControl.SkinLabel();
            this.skinLabel18 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel20 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_MB_Battery_rTest = new CCWin.SkinControl.SkinButton();
            this.skinButton_MB_Battery_Skip = new CCWin.SkinControl.SkinButton();
            this.skinLabel_MB_Battery_Result = new CCWin.SkinControl.SkinLabel();
            this.skinLabel24 = new CCWin.SkinControl.SkinLabel();
            this.skinTabPage_MB_STOPTEST = new CCWin.SkinControl.SkinTabPage();
            this.skinSplitContainer19 = new CCWin.SkinControl.SkinSplitContainer();
            this.skinLabel15 = new CCWin.SkinControl.SkinLabel();
            this.MB_TEMP_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.skinLabel21 = new CCWin.SkinControl.SkinLabel();
            this.MB_POWER_DOWN_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.skinLabel60 = new CCWin.SkinControl.SkinLabel();
            this.MB_BATTERY_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.skinLabel22 = new CCWin.SkinControl.SkinLabel();
            this.MB_TEST_START_TIME = new CCWin.SkinControl.SkinLabel();
            this.skinLabel85 = new CCWin.SkinControl.SkinLabel();
            this.MB_TEST_USED_TIME_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_LOCK_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_BT_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_POWER_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_ALL_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_FW_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_TESTOR_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_PCB_RESULT_VAL = new CCWin.SkinControl.SkinLabel();
            this.MB_TEST_USED_TIME = new CCWin.SkinControl.SkinLabel();
            this.MB_FLASH_RESULT = new CCWin.SkinControl.SkinLabel();
            this.MB_LED_RESULT = new CCWin.SkinControl.SkinLabel();
            this.MB_POWER_RESULT = new CCWin.SkinControl.SkinLabel();
            this.MB_ALL_RESULT = new CCWin.SkinControl.SkinLabel();
            this.MB_FW_RESULT = new CCWin.SkinControl.SkinLabel();
            this.MB_TESTOR_RESULT = new CCWin.SkinControl.SkinLabel();
            this.MB_PCB_RESULT = new CCWin.SkinControl.SkinLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.skinButton_PCBA_CLEAR_LOG = new CCWin.SkinControl.SkinButton();
            this.textBoxDebug = new System.Windows.Forms.TextBox();
            this.skinTabPage_Config = new CCWin.SkinControl.SkinTabPage();
            this.tableLayoutPanelSerialSetting = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownTestWaittime = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.numericUpDown_TempLowerLimit = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.numericUpDown_TempUpperLimit = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox_ChargerModel = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.skinButton_SerialCtrl = new CCWin.SkinControl.SkinButton();
            this.skinComboBox_BandRate = new CCWin.SkinControl.SkinComboBox();
            this.skinComboBox_SerialPortNum = new CCWin.SkinControl.SkinComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.skinButton_AccountSetting = new CCWin.SkinControl.SkinButton();
            this.skinButton_SaveConfig = new CCWin.SkinControl.SkinButton();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.skinTabControl_Menu.SuspendLayout();
            this.skinTabPage_PCBA.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.skinTabControl_MB.SuspendLayout();
            this.skinTabPage_MB_PCBANum.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer1)).BeginInit();
            this.skinSplitContainer1.Panel1.SuspendLayout();
            this.skinSplitContainer1.Panel2.SuspendLayout();
            this.skinSplitContainer1.SuspendLayout();
            this.skinTabPage_MB_Power.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer2)).BeginInit();
            this.skinSplitContainer2.Panel1.SuspendLayout();
            this.skinSplitContainer2.Panel2.SuspendLayout();
            this.skinSplitContainer2.SuspendLayout();
            this.skinTabPage_MB_BT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer17)).BeginInit();
            this.skinSplitContainer17.Panel1.SuspendLayout();
            this.skinSplitContainer17.Panel2.SuspendLayout();
            this.skinSplitContainer17.SuspendLayout();
            this.skinTabPage_MB_Temp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer3)).BeginInit();
            this.skinSplitContainer3.Panel1.SuspendLayout();
            this.skinSplitContainer3.Panel2.SuspendLayout();
            this.skinSplitContainer3.SuspendLayout();
            this.skinTabPage_MB_Lock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer4)).BeginInit();
            this.skinSplitContainer4.Panel1.SuspendLayout();
            this.skinSplitContainer4.Panel2.SuspendLayout();
            this.skinSplitContainer4.SuspendLayout();
            this.skinTabPage_MB_PowerDown.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer5)).BeginInit();
            this.skinSplitContainer5.Panel1.SuspendLayout();
            this.skinSplitContainer5.Panel2.SuspendLayout();
            this.skinSplitContainer5.SuspendLayout();
            this.skinTabPage_MB_Battery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer6)).BeginInit();
            this.skinSplitContainer6.Panel1.SuspendLayout();
            this.skinSplitContainer6.Panel2.SuspendLayout();
            this.skinSplitContainer6.SuspendLayout();
            this.skinTabPage_MB_STOPTEST.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer19)).BeginInit();
            this.skinSplitContainer19.Panel1.SuspendLayout();
            this.skinSplitContainer19.Panel2.SuspendLayout();
            this.skinSplitContainer19.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.skinTabPage_Config.SuspendLayout();
            this.tableLayoutPanelSerialSetting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTestWaittime)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TempLowerLimit)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TempUpperLimit)).BeginInit();
            this.SuspendLayout();
            // 
            // skinTabControl_Menu
            // 
            this.skinTabControl_Menu.AnimatorType = CCWin.SkinControl.AnimationType.HorizSlide;
            this.skinTabControl_Menu.CloseRect = new System.Drawing.Rectangle(2, 2, 12, 12);
            this.skinTabControl_Menu.Controls.Add(this.skinTabPage_PCBA);
            this.skinTabControl_Menu.Controls.Add(this.skinTabPage_Config);
            this.skinTabControl_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabControl_Menu.HeadBack = null;
            this.skinTabControl_Menu.ImgTxtOffset = new System.Drawing.Point(0, 0);
            this.skinTabControl_Menu.ItemSize = new System.Drawing.Size(180, 100);
            this.skinTabControl_Menu.Location = new System.Drawing.Point(0, 0);
            this.skinTabControl_Menu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabControl_Menu.Name = "skinTabControl_Menu";
            this.skinTabControl_Menu.PageArrowDown = ((System.Drawing.Image)(resources.GetObject("skinTabControl_Menu.PageArrowDown")));
            this.skinTabControl_Menu.PageArrowHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl_Menu.PageArrowHover")));
            this.skinTabControl_Menu.PageCloseHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl_Menu.PageCloseHover")));
            this.skinTabControl_Menu.PageCloseNormal = ((System.Drawing.Image)(resources.GetObject("skinTabControl_Menu.PageCloseNormal")));
            this.skinTabControl_Menu.PageDown = ((System.Drawing.Image)(resources.GetObject("skinTabControl_Menu.PageDown")));
            this.skinTabControl_Menu.PageHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl_Menu.PageHover")));
            this.skinTabControl_Menu.PageImagePosition = CCWin.SkinControl.SkinTabControl.ePageImagePosition.Left;
            this.skinTabControl_Menu.PageNorml = null;
            this.skinTabControl_Menu.SelectedIndex = 0;
            this.skinTabControl_Menu.Size = new System.Drawing.Size(1556, 785);
            this.skinTabControl_Menu.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.skinTabControl_Menu.TabIndex = 0;
            this.skinTabControl_Menu.SelectedIndexChanged += new System.EventHandler(this.skinTabControl_Menu_SelectedIndexChanged);
            this.skinTabControl_Menu.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.skinTabControl_Menu_Selecting);
            // 
            // skinTabPage_PCBA
            // 
            this.skinTabPage_PCBA.BackColor = System.Drawing.Color.White;
            this.skinTabPage_PCBA.Controls.Add(this.tableLayoutPanel4);
            this.skinTabPage_PCBA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_PCBA.Location = new System.Drawing.Point(0, 100);
            this.skinTabPage_PCBA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabPage_PCBA.Name = "skinTabPage_PCBA";
            this.skinTabPage_PCBA.Size = new System.Drawing.Size(1556, 685);
            this.skinTabPage_PCBA.TabIndex = 0;
            this.skinTabPage_PCBA.TabItemImage = null;
            this.skinTabPage_PCBA.Text = "PCBA测试";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.86633F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.13367F));
            this.tableLayoutPanel4.Controls.Add(this.skinTabControl_MB, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1556, 685);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // skinTabControl_MB
            // 
            this.skinTabControl_MB.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.skinTabControl_MB.AnimationStart = true;
            this.skinTabControl_MB.AnimatorType = CCWin.SkinControl.AnimationType.VertSlide;
            this.skinTabControl_MB.BackColor = System.Drawing.Color.LightSteelBlue;
            this.skinTabControl_MB.CloseRect = new System.Drawing.Rectangle(2, 2, 12, 12);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_PCBANum);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_Power);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_BT);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_Temp);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_Lock);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_PowerDown);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_Battery);
            this.skinTabControl_MB.Controls.Add(this.skinTabPage_MB_STOPTEST);
            this.skinTabControl_MB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabControl_MB.HeadBack = null;
            this.skinTabControl_MB.ImgTxtOffset = new System.Drawing.Point(0, 0);
            this.skinTabControl_MB.ItemSize = new System.Drawing.Size(40, 100);
            this.skinTabControl_MB.Location = new System.Drawing.Point(4, 3);
            this.skinTabControl_MB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabControl_MB.Multiline = true;
            this.skinTabControl_MB.Name = "skinTabControl_MB";
            this.skinTabControl_MB.PageArrowDown = ((System.Drawing.Image)(resources.GetObject("skinTabControl_MB.PageArrowDown")));
            this.skinTabControl_MB.PageArrowHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl_MB.PageArrowHover")));
            this.skinTabControl_MB.PageCloseHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl_MB.PageCloseHover")));
            this.skinTabControl_MB.PageCloseNormal = ((System.Drawing.Image)(resources.GetObject("skinTabControl_MB.PageCloseNormal")));
            this.skinTabControl_MB.PageDown = ((System.Drawing.Image)(resources.GetObject("skinTabControl_MB.PageDown")));
            this.skinTabControl_MB.PageHover = ((System.Drawing.Image)(resources.GetObject("skinTabControl_MB.PageHover")));
            this.skinTabControl_MB.PageImagePosition = CCWin.SkinControl.SkinTabControl.ePageImagePosition.Left;
            this.skinTabControl_MB.PageNorml = null;
            this.skinTabControl_MB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinTabControl_MB.SelectedIndex = 4;
            this.skinTabControl_MB.Size = new System.Drawing.Size(1048, 679);
            this.skinTabControl_MB.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.skinTabControl_MB.TabIndex = 3;
            this.skinTabControl_MB.SelectedIndexChanged += new System.EventHandler(this.skinTabControl_MB_SelectedIndexChanged);
            // 
            // skinTabPage_MB_PCBANum
            // 
            this.skinTabPage_MB_PCBANum.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_PCBANum.Controls.Add(this.skinSplitContainer1);
            this.skinTabPage_MB_PCBANum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_PCBANum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_PCBANum.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_PCBANum.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabPage_MB_PCBANum.Name = "skinTabPage_MB_PCBANum";
            this.skinTabPage_MB_PCBANum.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_PCBANum.TabIndex = 0;
            this.skinTabPage_MB_PCBANum.TabItemImage = null;
            this.skinTabPage_MB_PCBANum.Text = "PCBA编号";
            // 
            // skinSplitContainer1
            // 
            this.skinSplitContainer1.BackColor = System.Drawing.Color.White;
            this.skinSplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.skinSplitContainer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer1.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer1.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer1.Name = "skinSplitContainer1";
            this.skinSplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer1.Panel1
            // 
            this.skinSplitContainer1.Panel1.Controls.Add(this.skinLabel_PCBANumTip);
            this.skinSplitContainer1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer1.Panel2
            // 
            this.skinSplitContainer1.Panel2.Controls.Add(this.skinButton_MB_Confirm);
            this.skinSplitContainer1.Panel2.Controls.Add(this.skinLabel_PCBANumStartTip);
            this.skinSplitContainer1.Panel2.Controls.Add(this.textBox_MB_QRCode);
            this.skinSplitContainer1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer1.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer1.SplitterDistance = 98;
            this.skinSplitContainer1.SplitterWidth = 5;
            this.skinSplitContainer1.TabIndex = 0;
            // 
            // skinLabel_PCBANumTip
            // 
            this.skinLabel_PCBANumTip.AutoSize = true;
            this.skinLabel_PCBANumTip.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_PCBANumTip.BorderColor = System.Drawing.Color.White;
            this.skinLabel_PCBANumTip.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_PCBANumTip.Location = new System.Drawing.Point(40, 27);
            this.skinLabel_PCBANumTip.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_PCBANumTip.Name = "skinLabel_PCBANumTip";
            this.skinLabel_PCBANumTip.Size = new System.Drawing.Size(315, 33);
            this.skinLabel_PCBANumTip.TabIndex = 0;
            this.skinLabel_PCBANumTip.Text = "请用扫码枪扫描主板二维码";
            // 
            // skinButton_MB_Confirm
            // 
            this.skinButton_MB_Confirm.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Confirm.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Confirm.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Confirm.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Confirm.DownBack = null;
            this.skinButton_MB_Confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton_MB_Confirm.ForeColorSuit = true;
            this.skinButton_MB_Confirm.Location = new System.Drawing.Point(46, 182);
            this.skinButton_MB_Confirm.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Confirm.MouseBack = null;
            this.skinButton_MB_Confirm.Name = "skinButton_MB_Confirm";
            this.skinButton_MB_Confirm.NormlBack = null;
            this.skinButton_MB_Confirm.Radius = 15;
            this.skinButton_MB_Confirm.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Confirm.Size = new System.Drawing.Size(210, 57);
            this.skinButton_MB_Confirm.TabIndex = 2;
            this.skinButton_MB_Confirm.Text = "确认";
            this.skinButton_MB_Confirm.UseVisualStyleBackColor = false;
            this.skinButton_MB_Confirm.Click += new System.EventHandler(this.skinButton_MB_Confirm_Click);
            // 
            // skinLabel_PCBANumStartTip
            // 
            this.skinLabel_PCBANumStartTip.AutoSize = true;
            this.skinLabel_PCBANumStartTip.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_PCBANumStartTip.BorderColor = System.Drawing.Color.White;
            this.skinLabel_PCBANumStartTip.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_PCBANumStartTip.Location = new System.Drawing.Point(51, 87);
            this.skinLabel_PCBANumStartTip.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_PCBANumStartTip.Name = "skinLabel_PCBANumStartTip";
            this.skinLabel_PCBANumStartTip.Size = new System.Drawing.Size(402, 24);
            this.skinLabel_PCBANumStartTip.TabIndex = 1;
            this.skinLabel_PCBANumStartTip.Text = "输入完成按键盘\"回车键\"或以下\"确认键\"开始测试";
            // 
            // textBox_MB_QRCode
            // 
            this.textBox_MB_QRCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBox_MB_QRCode.Location = new System.Drawing.Point(46, 22);
            this.textBox_MB_QRCode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox_MB_QRCode.MaxLength = 100;
            this.textBox_MB_QRCode.Name = "textBox_MB_QRCode";
            this.textBox_MB_QRCode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_MB_QRCode.Size = new System.Drawing.Size(505, 30);
            this.textBox_MB_QRCode.TabIndex = 0;
            this.textBox_MB_QRCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_MB_QRCode_KeyPress);
            // 
            // skinTabPage_MB_Power
            // 
            this.skinTabPage_MB_Power.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_Power.Controls.Add(this.skinSplitContainer2);
            this.skinTabPage_MB_Power.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_Power.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_Power.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_Power.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabPage_MB_Power.Name = "skinTabPage_MB_Power";
            this.skinTabPage_MB_Power.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_Power.TabIndex = 1;
            this.skinTabPage_MB_Power.TabItemImage = null;
            this.skinTabPage_MB_Power.Text = "电源";
            // 
            // skinSplitContainer2
            // 
            this.skinSplitContainer2.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer2.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer2.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer2.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer2.Name = "skinSplitContainer2";
            this.skinSplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer2.Panel1
            // 
            this.skinSplitContainer2.Panel1.Controls.Add(this.skinLabel_MB_PowerTimeCountDown);
            this.skinSplitContainer2.Panel1.Controls.Add(this.skinLabel3);
            this.skinSplitContainer2.Panel1.Controls.Add(this.skinLabel2);
            this.skinSplitContainer2.Panel1.Controls.Add(this.skinLabel1);
            this.skinSplitContainer2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer2.Panel2
            // 
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinButton_MB_Power_Success);
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinLabel_MB_POWER_RESULT);
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinButton_MB_Power_rTest);
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinButton_MB_Power_Over);
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinButton_MB_Power_Fail);
            this.skinSplitContainer2.Panel2.Controls.Add(this.skinLabel4);
            this.skinSplitContainer2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer2.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer2.SplitterDistance = 137;
            this.skinSplitContainer2.SplitterWidth = 5;
            this.skinSplitContainer2.TabIndex = 0;
            // 
            // skinLabel_MB_PowerTimeCountDown
            // 
            this.skinLabel_MB_PowerTimeCountDown.AutoSize = true;
            this.skinLabel_MB_PowerTimeCountDown.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_PowerTimeCountDown.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_PowerTimeCountDown.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_PowerTimeCountDown.Location = new System.Drawing.Point(683, 18);
            this.skinLabel_MB_PowerTimeCountDown.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_PowerTimeCountDown.Name = "skinLabel_MB_PowerTimeCountDown";
            this.skinLabel_MB_PowerTimeCountDown.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_PowerTimeCountDown.TabIndex = 3;
            // 
            // skinLabel3
            // 
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel3.Location = new System.Drawing.Point(25, 67);
            this.skinLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(542, 31);
            this.skinLabel3.TabIndex = 2;
            this.skinLabel3.Text = "请在夹具右上方看电压表电压值是否在正常范围内";
            // 
            // skinLabel2
            // 
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.Location = new System.Drawing.Point(563, 18);
            this.skinLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(92, 31);
            this.skinLabel2.TabIndex = 1;
            this.skinLabel2.Text = "倒计时:";
            // 
            // skinLabel1
            // 
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.Location = new System.Drawing.Point(25, 18);
            this.skinLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(212, 31);
            this.skinLabel1.TabIndex = 0;
            this.skinLabel1.Text = "当前项目:电源测试";
            // 
            // skinButton_MB_Power_Success
            // 
            this.skinButton_MB_Power_Success.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Power_Success.BaseColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_Success.BorderColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_Success.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Power_Success.DownBack = null;
            this.skinButton_MB_Power_Success.Location = new System.Drawing.Point(194, 93);
            this.skinButton_MB_Power_Success.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Power_Success.MouseBack = null;
            this.skinButton_MB_Power_Success.Name = "skinButton_MB_Power_Success";
            this.skinButton_MB_Power_Success.NormlBack = null;
            this.skinButton_MB_Power_Success.Radius = 15;
            this.skinButton_MB_Power_Success.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Power_Success.Size = new System.Drawing.Size(147, 50);
            this.skinButton_MB_Power_Success.TabIndex = 6;
            this.skinButton_MB_Power_Success.Text = "成功";
            this.skinButton_MB_Power_Success.UseVisualStyleBackColor = false;
            this.skinButton_MB_Power_Success.Click += new System.EventHandler(this.skinButton_MB_Power_Success_Click);
            // 
            // skinLabel_MB_POWER_RESULT
            // 
            this.skinLabel_MB_POWER_RESULT.AutoSize = true;
            this.skinLabel_MB_POWER_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_POWER_RESULT.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_POWER_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_POWER_RESULT.Location = new System.Drawing.Point(181, 27);
            this.skinLabel_MB_POWER_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_POWER_RESULT.Name = "skinLabel_MB_POWER_RESULT";
            this.skinLabel_MB_POWER_RESULT.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_POWER_RESULT.TabIndex = 5;
            // 
            // skinButton_MB_Power_rTest
            // 
            this.skinButton_MB_Power_rTest.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Power_rTest.BaseColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_rTest.BorderColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_rTest.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Power_rTest.DownBack = null;
            this.skinButton_MB_Power_rTest.Location = new System.Drawing.Point(393, 208);
            this.skinButton_MB_Power_rTest.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Power_rTest.MouseBack = null;
            this.skinButton_MB_Power_rTest.Name = "skinButton_MB_Power_rTest";
            this.skinButton_MB_Power_rTest.NormlBack = null;
            this.skinButton_MB_Power_rTest.Radius = 15;
            this.skinButton_MB_Power_rTest.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Power_rTest.Size = new System.Drawing.Size(147, 50);
            this.skinButton_MB_Power_rTest.TabIndex = 4;
            this.skinButton_MB_Power_rTest.Text = "重新测试";
            this.skinButton_MB_Power_rTest.UseVisualStyleBackColor = false;
            this.skinButton_MB_Power_rTest.Click += new System.EventHandler(this.skinButton_MB_Power_rTest_Click);
            // 
            // skinButton_MB_Power_Over
            // 
            this.skinButton_MB_Power_Over.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Power_Over.BaseColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_Over.BorderColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_Over.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Power_Over.DownBack = null;
            this.skinButton_MB_Power_Over.Location = new System.Drawing.Point(194, 208);
            this.skinButton_MB_Power_Over.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Power_Over.MouseBack = null;
            this.skinButton_MB_Power_Over.Name = "skinButton_MB_Power_Over";
            this.skinButton_MB_Power_Over.NormlBack = null;
            this.skinButton_MB_Power_Over.Radius = 15;
            this.skinButton_MB_Power_Over.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Power_Over.Size = new System.Drawing.Size(147, 50);
            this.skinButton_MB_Power_Over.TabIndex = 3;
            this.skinButton_MB_Power_Over.Text = "跳过";
            this.skinButton_MB_Power_Over.UseVisualStyleBackColor = false;
            this.skinButton_MB_Power_Over.Click += new System.EventHandler(this.skinButton_MB_Power_Over_Click);
            // 
            // skinButton_MB_Power_Fail
            // 
            this.skinButton_MB_Power_Fail.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Power_Fail.BaseColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_Fail.BorderColor = System.Drawing.Color.Silver;
            this.skinButton_MB_Power_Fail.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Power_Fail.DownBack = null;
            this.skinButton_MB_Power_Fail.Location = new System.Drawing.Point(393, 93);
            this.skinButton_MB_Power_Fail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Power_Fail.MouseBack = null;
            this.skinButton_MB_Power_Fail.Name = "skinButton_MB_Power_Fail";
            this.skinButton_MB_Power_Fail.NormlBack = null;
            this.skinButton_MB_Power_Fail.Radius = 15;
            this.skinButton_MB_Power_Fail.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Power_Fail.Size = new System.Drawing.Size(147, 50);
            this.skinButton_MB_Power_Fail.TabIndex = 2;
            this.skinButton_MB_Power_Fail.Text = "失败";
            this.skinButton_MB_Power_Fail.UseVisualStyleBackColor = false;
            this.skinButton_MB_Power_Fail.Click += new System.EventHandler(this.skinButton_MB_Power_Fail_Click);
            // 
            // skinLabel4
            // 
            this.skinLabel4.AutoSize = true;
            this.skinLabel4.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel4.BorderColor = System.Drawing.Color.White;
            this.skinLabel4.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel4.Location = new System.Drawing.Point(28, 27);
            this.skinLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel4.Name = "skinLabel4";
            this.skinLabel4.Size = new System.Drawing.Size(116, 31);
            this.skinLabel4.TabIndex = 0;
            this.skinLabel4.Text = "测试结果:";
            // 
            // skinTabPage_MB_BT
            // 
            this.skinTabPage_MB_BT.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_BT.Controls.Add(this.skinSplitContainer17);
            this.skinTabPage_MB_BT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_BT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_BT.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_BT.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabPage_MB_BT.Name = "skinTabPage_MB_BT";
            this.skinTabPage_MB_BT.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_BT.TabIndex = 10;
            this.skinTabPage_MB_BT.TabItemImage = null;
            this.skinTabPage_MB_BT.Text = "蓝牙";
            // 
            // skinSplitContainer17
            // 
            this.skinSplitContainer17.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer17.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer17.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer17.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer17.Name = "skinSplitContainer17";
            this.skinSplitContainer17.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer17.Panel1
            // 
            this.skinSplitContainer17.Panel1.Controls.Add(this.skinLabel5);
            this.skinSplitContainer17.Panel1.Controls.Add(this.skinLabel_MB_BT_TIME);
            this.skinSplitContainer17.Panel1.Controls.Add(this.skinLabel50);
            this.skinSplitContainer17.Panel1.Controls.Add(this.skinLabel66);
            this.skinSplitContainer17.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer17.Panel2
            // 
            this.skinSplitContainer17.Panel2.Controls.Add(this.skinButton_MB_BT_FAIL);
            this.skinSplitContainer17.Panel2.Controls.Add(this.skinButton_MB_BT_SUCCESS);
            this.skinSplitContainer17.Panel2.Controls.Add(this.skinButton_MB_BT_RETEST);
            this.skinSplitContainer17.Panel2.Controls.Add(this.skinButton_MB_BT_SKIP);
            this.skinSplitContainer17.Panel2.Controls.Add(this.skinLabel_MB_BT_RESULT);
            this.skinSplitContainer17.Panel2.Controls.Add(this.skinLabel68);
            this.skinSplitContainer17.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer17.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer17.SplitterDistance = 127;
            this.skinSplitContainer17.SplitterWidth = 5;
            this.skinSplitContainer17.TabIndex = 3;
            // 
            // skinLabel5
            // 
            this.skinLabel5.AutoSize = true;
            this.skinLabel5.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel5.BorderColor = System.Drawing.Color.White;
            this.skinLabel5.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel5.Location = new System.Drawing.Point(60, 86);
            this.skinLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel5.Name = "skinLabel5";
            this.skinLabel5.Size = new System.Drawing.Size(398, 31);
            this.skinLabel5.TabIndex = 3;
            this.skinLabel5.Text = "请肉眼观察蓝牙连接指示灯是否亮起";
            // 
            // skinLabel_MB_BT_TIME
            // 
            this.skinLabel_MB_BT_TIME.AutoSize = true;
            this.skinLabel_MB_BT_TIME.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_BT_TIME.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_BT_TIME.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_BT_TIME.Location = new System.Drawing.Point(654, 28);
            this.skinLabel_MB_BT_TIME.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_BT_TIME.Name = "skinLabel_MB_BT_TIME";
            this.skinLabel_MB_BT_TIME.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_BT_TIME.TabIndex = 2;
            // 
            // skinLabel50
            // 
            this.skinLabel50.AutoSize = true;
            this.skinLabel50.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel50.BorderColor = System.Drawing.Color.White;
            this.skinLabel50.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel50.Location = new System.Drawing.Point(532, 28);
            this.skinLabel50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel50.Name = "skinLabel50";
            this.skinLabel50.Size = new System.Drawing.Size(92, 31);
            this.skinLabel50.TabIndex = 1;
            this.skinLabel50.Text = "倒计时:";
            // 
            // skinLabel66
            // 
            this.skinLabel66.AutoSize = true;
            this.skinLabel66.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel66.BorderColor = System.Drawing.Color.White;
            this.skinLabel66.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel66.Location = new System.Drawing.Point(60, 28);
            this.skinLabel66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel66.Name = "skinLabel66";
            this.skinLabel66.Size = new System.Drawing.Size(212, 31);
            this.skinLabel66.TabIndex = 0;
            this.skinLabel66.Text = "当前项目:蓝牙测试";
            // 
            // skinButton_MB_BT_FAIL
            // 
            this.skinButton_MB_BT_FAIL.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_BT_FAIL.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_FAIL.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_FAIL.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_BT_FAIL.DownBack = null;
            this.skinButton_MB_BT_FAIL.Location = new System.Drawing.Point(445, 144);
            this.skinButton_MB_BT_FAIL.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_BT_FAIL.MouseBack = null;
            this.skinButton_MB_BT_FAIL.Name = "skinButton_MB_BT_FAIL";
            this.skinButton_MB_BT_FAIL.NormlBack = null;
            this.skinButton_MB_BT_FAIL.Radius = 15;
            this.skinButton_MB_BT_FAIL.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_BT_FAIL.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_BT_FAIL.TabIndex = 13;
            this.skinButton_MB_BT_FAIL.Text = "失败";
            this.skinButton_MB_BT_FAIL.UseVisualStyleBackColor = false;
            this.skinButton_MB_BT_FAIL.Click += new System.EventHandler(this.skinButton_MB_BT_FAIL_Click);
            // 
            // skinButton_MB_BT_SUCCESS
            // 
            this.skinButton_MB_BT_SUCCESS.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_BT_SUCCESS.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_SUCCESS.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_SUCCESS.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_BT_SUCCESS.DownBack = null;
            this.skinButton_MB_BT_SUCCESS.Location = new System.Drawing.Point(211, 144);
            this.skinButton_MB_BT_SUCCESS.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_BT_SUCCESS.MouseBack = null;
            this.skinButton_MB_BT_SUCCESS.Name = "skinButton_MB_BT_SUCCESS";
            this.skinButton_MB_BT_SUCCESS.NormlBack = null;
            this.skinButton_MB_BT_SUCCESS.Radius = 15;
            this.skinButton_MB_BT_SUCCESS.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_BT_SUCCESS.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_BT_SUCCESS.TabIndex = 12;
            this.skinButton_MB_BT_SUCCESS.Text = "成功";
            this.skinButton_MB_BT_SUCCESS.UseVisualStyleBackColor = false;
            this.skinButton_MB_BT_SUCCESS.Click += new System.EventHandler(this.skinButton_MB_BT_SUCCESS_Click);
            // 
            // skinButton_MB_BT_RETEST
            // 
            this.skinButton_MB_BT_RETEST.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_BT_RETEST.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_RETEST.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_RETEST.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_BT_RETEST.DownBack = null;
            this.skinButton_MB_BT_RETEST.Location = new System.Drawing.Point(445, 253);
            this.skinButton_MB_BT_RETEST.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_BT_RETEST.MouseBack = null;
            this.skinButton_MB_BT_RETEST.Name = "skinButton_MB_BT_RETEST";
            this.skinButton_MB_BT_RETEST.NormlBack = null;
            this.skinButton_MB_BT_RETEST.Radius = 15;
            this.skinButton_MB_BT_RETEST.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_BT_RETEST.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_BT_RETEST.TabIndex = 11;
            this.skinButton_MB_BT_RETEST.Text = "重新测试";
            this.skinButton_MB_BT_RETEST.UseVisualStyleBackColor = false;
            this.skinButton_MB_BT_RETEST.Click += new System.EventHandler(this.skinButton_MB_BT_RETEST_Click);
            // 
            // skinButton_MB_BT_SKIP
            // 
            this.skinButton_MB_BT_SKIP.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_BT_SKIP.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_SKIP.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_BT_SKIP.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_BT_SKIP.DownBack = null;
            this.skinButton_MB_BT_SKIP.Location = new System.Drawing.Point(211, 253);
            this.skinButton_MB_BT_SKIP.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_BT_SKIP.MouseBack = null;
            this.skinButton_MB_BT_SKIP.Name = "skinButton_MB_BT_SKIP";
            this.skinButton_MB_BT_SKIP.NormlBack = null;
            this.skinButton_MB_BT_SKIP.Radius = 15;
            this.skinButton_MB_BT_SKIP.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_BT_SKIP.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_BT_SKIP.TabIndex = 10;
            this.skinButton_MB_BT_SKIP.Text = "跳过";
            this.skinButton_MB_BT_SKIP.UseVisualStyleBackColor = false;
            this.skinButton_MB_BT_SKIP.Click += new System.EventHandler(this.skinButton_MB_BT_SKIP_Click);
            // 
            // skinLabel_MB_BT_RESULT
            // 
            this.skinLabel_MB_BT_RESULT.AutoSize = true;
            this.skinLabel_MB_BT_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_BT_RESULT.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_BT_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_BT_RESULT.Location = new System.Drawing.Point(211, 30);
            this.skinLabel_MB_BT_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_BT_RESULT.Name = "skinLabel_MB_BT_RESULT";
            this.skinLabel_MB_BT_RESULT.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_BT_RESULT.TabIndex = 4;
            // 
            // skinLabel68
            // 
            this.skinLabel68.AutoSize = true;
            this.skinLabel68.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel68.BorderColor = System.Drawing.Color.White;
            this.skinLabel68.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel68.Location = new System.Drawing.Point(60, 27);
            this.skinLabel68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel68.Name = "skinLabel68";
            this.skinLabel68.Size = new System.Drawing.Size(116, 31);
            this.skinLabel68.TabIndex = 3;
            this.skinLabel68.Text = "测试结果:";
            // 
            // skinTabPage_MB_Temp
            // 
            this.skinTabPage_MB_Temp.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_Temp.Controls.Add(this.skinSplitContainer3);
            this.skinTabPage_MB_Temp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_Temp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_Temp.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_Temp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.skinTabPage_MB_Temp.Name = "skinTabPage_MB_Temp";
            this.skinTabPage_MB_Temp.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_Temp.TabIndex = 11;
            this.skinTabPage_MB_Temp.TabItemImage = null;
            this.skinTabPage_MB_Temp.Text = "温度";
            // 
            // skinSplitContainer3
            // 
            this.skinSplitContainer3.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer3.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer3.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer3.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer3.Name = "skinSplitContainer3";
            this.skinSplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer3.Panel1
            // 
            this.skinSplitContainer3.Panel1.Controls.Add(this.skinLabel_MB_TEMP_TIME);
            this.skinSplitContainer3.Panel1.Controls.Add(this.skinLabel8);
            this.skinSplitContainer3.Panel1.Controls.Add(this.skinLabel9);
            this.skinSplitContainer3.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer3.Panel2
            // 
            this.skinSplitContainer3.Panel2.Controls.Add(this.skinLabel_MB_Temp_Result1);
            this.skinSplitContainer3.Panel2.Controls.Add(this.skinButton_MB_Temp_rTest);
            this.skinSplitContainer3.Panel2.Controls.Add(this.skinButton_MB_Temp_Skip);
            this.skinSplitContainer3.Panel2.Controls.Add(this.skinLabel_MB_Temp_Result);
            this.skinSplitContainer3.Panel2.Controls.Add(this.skinLabel11);
            this.skinSplitContainer3.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer3.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer3.SplitterDistance = 73;
            this.skinSplitContainer3.SplitterWidth = 5;
            this.skinSplitContainer3.TabIndex = 4;
            // 
            // skinLabel_MB_TEMP_TIME
            // 
            this.skinLabel_MB_TEMP_TIME.AutoSize = true;
            this.skinLabel_MB_TEMP_TIME.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_TEMP_TIME.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_TEMP_TIME.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_TEMP_TIME.Location = new System.Drawing.Point(654, 28);
            this.skinLabel_MB_TEMP_TIME.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_TEMP_TIME.Name = "skinLabel_MB_TEMP_TIME";
            this.skinLabel_MB_TEMP_TIME.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_TEMP_TIME.TabIndex = 2;
            // 
            // skinLabel8
            // 
            this.skinLabel8.AutoSize = true;
            this.skinLabel8.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel8.BorderColor = System.Drawing.Color.White;
            this.skinLabel8.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel8.Location = new System.Drawing.Point(532, 28);
            this.skinLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel8.Name = "skinLabel8";
            this.skinLabel8.Size = new System.Drawing.Size(92, 31);
            this.skinLabel8.TabIndex = 1;
            this.skinLabel8.Text = "倒计时:";
            // 
            // skinLabel9
            // 
            this.skinLabel9.AutoSize = true;
            this.skinLabel9.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel9.BorderColor = System.Drawing.Color.White;
            this.skinLabel9.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel9.Location = new System.Drawing.Point(60, 28);
            this.skinLabel9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel9.Name = "skinLabel9";
            this.skinLabel9.Size = new System.Drawing.Size(212, 31);
            this.skinLabel9.TabIndex = 0;
            this.skinLabel9.Text = "当前项目:温度检测";
            // 
            // skinLabel_MB_Temp_Result1
            // 
            this.skinLabel_MB_Temp_Result1.AutoSize = true;
            this.skinLabel_MB_Temp_Result1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Temp_Result1.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Temp_Result1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Temp_Result1.Location = new System.Drawing.Point(445, 30);
            this.skinLabel_MB_Temp_Result1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Temp_Result1.Name = "skinLabel_MB_Temp_Result1";
            this.skinLabel_MB_Temp_Result1.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Temp_Result1.TabIndex = 41;
            // 
            // skinButton_MB_Temp_rTest
            // 
            this.skinButton_MB_Temp_rTest.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Temp_rTest.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Temp_rTest.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Temp_rTest.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Temp_rTest.DownBack = null;
            this.skinButton_MB_Temp_rTest.Location = new System.Drawing.Point(445, 275);
            this.skinButton_MB_Temp_rTest.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Temp_rTest.MouseBack = null;
            this.skinButton_MB_Temp_rTest.Name = "skinButton_MB_Temp_rTest";
            this.skinButton_MB_Temp_rTest.NormlBack = null;
            this.skinButton_MB_Temp_rTest.Radius = 15;
            this.skinButton_MB_Temp_rTest.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Temp_rTest.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_Temp_rTest.TabIndex = 11;
            this.skinButton_MB_Temp_rTest.Text = "重新测试";
            this.skinButton_MB_Temp_rTest.UseVisualStyleBackColor = false;
            this.skinButton_MB_Temp_rTest.Click += new System.EventHandler(this.skinButton_MB_Temp_rTest_Click);
            // 
            // skinButton_MB_Temp_Skip
            // 
            this.skinButton_MB_Temp_Skip.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Temp_Skip.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Temp_Skip.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Temp_Skip.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Temp_Skip.DownBack = null;
            this.skinButton_MB_Temp_Skip.Location = new System.Drawing.Point(211, 275);
            this.skinButton_MB_Temp_Skip.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Temp_Skip.MouseBack = null;
            this.skinButton_MB_Temp_Skip.Name = "skinButton_MB_Temp_Skip";
            this.skinButton_MB_Temp_Skip.NormlBack = null;
            this.skinButton_MB_Temp_Skip.Radius = 15;
            this.skinButton_MB_Temp_Skip.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Temp_Skip.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_Temp_Skip.TabIndex = 10;
            this.skinButton_MB_Temp_Skip.Text = "跳过";
            this.skinButton_MB_Temp_Skip.UseVisualStyleBackColor = false;
            this.skinButton_MB_Temp_Skip.Click += new System.EventHandler(this.skinButton_MB_Temp_Skip_Click);
            // 
            // skinLabel_MB_Temp_Result
            // 
            this.skinLabel_MB_Temp_Result.AutoSize = true;
            this.skinLabel_MB_Temp_Result.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Temp_Result.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Temp_Result.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Temp_Result.Location = new System.Drawing.Point(211, 30);
            this.skinLabel_MB_Temp_Result.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Temp_Result.Name = "skinLabel_MB_Temp_Result";
            this.skinLabel_MB_Temp_Result.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Temp_Result.TabIndex = 40;
            // 
            // skinLabel11
            // 
            this.skinLabel11.AutoSize = true;
            this.skinLabel11.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel11.BorderColor = System.Drawing.Color.White;
            this.skinLabel11.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel11.Location = new System.Drawing.Point(60, 27);
            this.skinLabel11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel11.Name = "skinLabel11";
            this.skinLabel11.Size = new System.Drawing.Size(116, 31);
            this.skinLabel11.TabIndex = 3;
            this.skinLabel11.Text = "测试结果:";
            // 
            // skinTabPage_MB_Lock
            // 
            this.skinTabPage_MB_Lock.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_Lock.Controls.Add(this.skinSplitContainer4);
            this.skinTabPage_MB_Lock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_Lock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_Lock.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_Lock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.skinTabPage_MB_Lock.Name = "skinTabPage_MB_Lock";
            this.skinTabPage_MB_Lock.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_Lock.TabIndex = 12;
            this.skinTabPage_MB_Lock.TabItemImage = null;
            this.skinTabPage_MB_Lock.Text = "柜锁";
            // 
            // skinSplitContainer4
            // 
            this.skinSplitContainer4.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer4.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer4.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer4.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer4.Name = "skinSplitContainer4";
            this.skinSplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer4.Panel1
            // 
            this.skinSplitContainer4.Panel1.Controls.Add(this.skinLabel_MB_Lock_Time);
            this.skinSplitContainer4.Panel1.Controls.Add(this.skinLabel7);
            this.skinSplitContainer4.Panel1.Controls.Add(this.skinLabel10);
            this.skinSplitContainer4.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer4.Panel2
            // 
            this.skinSplitContainer4.Panel2.Controls.Add(this.skinLabel6);
            this.skinSplitContainer4.Panel2.Controls.Add(this.skinLabel_MB_Lock_Result1);
            this.skinSplitContainer4.Panel2.Controls.Add(this.skinButton_MB_Lock_rTest);
            this.skinSplitContainer4.Panel2.Controls.Add(this.skinButton_MB_Lock_Skip);
            this.skinSplitContainer4.Panel2.Controls.Add(this.skinLabel_MB_Lock_Result);
            this.skinSplitContainer4.Panel2.Controls.Add(this.skinLabel14);
            this.skinSplitContainer4.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer4.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer4.SplitterDistance = 70;
            this.skinSplitContainer4.SplitterWidth = 5;
            this.skinSplitContainer4.TabIndex = 5;
            // 
            // skinLabel_MB_Lock_Time
            // 
            this.skinLabel_MB_Lock_Time.AutoSize = true;
            this.skinLabel_MB_Lock_Time.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Lock_Time.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Lock_Time.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Lock_Time.Location = new System.Drawing.Point(654, 28);
            this.skinLabel_MB_Lock_Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Lock_Time.Name = "skinLabel_MB_Lock_Time";
            this.skinLabel_MB_Lock_Time.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Lock_Time.TabIndex = 2;
            // 
            // skinLabel7
            // 
            this.skinLabel7.AutoSize = true;
            this.skinLabel7.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel7.BorderColor = System.Drawing.Color.White;
            this.skinLabel7.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel7.Location = new System.Drawing.Point(532, 28);
            this.skinLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel7.Name = "skinLabel7";
            this.skinLabel7.Size = new System.Drawing.Size(92, 31);
            this.skinLabel7.TabIndex = 1;
            this.skinLabel7.Text = "倒计时:";
            // 
            // skinLabel10
            // 
            this.skinLabel10.AutoSize = true;
            this.skinLabel10.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel10.BorderColor = System.Drawing.Color.White;
            this.skinLabel10.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel10.Location = new System.Drawing.Point(60, 28);
            this.skinLabel10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel10.Name = "skinLabel10";
            this.skinLabel10.Size = new System.Drawing.Size(212, 31);
            this.skinLabel10.TabIndex = 0;
            this.skinLabel10.Text = "当前项目:柜锁检测";
            // 
            // skinLabel6
            // 
            this.skinLabel6.AutoSize = true;
            this.skinLabel6.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel6.BorderColor = System.Drawing.Color.White;
            this.skinLabel6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel6.Location = new System.Drawing.Point(60, 27);
            this.skinLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel6.Name = "skinLabel6";
            this.skinLabel6.Size = new System.Drawing.Size(495, 33);
            this.skinLabel6.TabIndex = 42;
            this.skinLabel6.Text = "温馨提示：1表示柜锁关闭，0表示柜锁打开";
            // 
            // skinLabel_MB_Lock_Result1
            // 
            this.skinLabel_MB_Lock_Result1.AutoSize = true;
            this.skinLabel_MB_Lock_Result1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Lock_Result1.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Lock_Result1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Lock_Result1.Location = new System.Drawing.Point(445, 85);
            this.skinLabel_MB_Lock_Result1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Lock_Result1.Name = "skinLabel_MB_Lock_Result1";
            this.skinLabel_MB_Lock_Result1.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Lock_Result1.TabIndex = 41;
            // 
            // skinButton_MB_Lock_rTest
            // 
            this.skinButton_MB_Lock_rTest.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Lock_rTest.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Lock_rTest.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Lock_rTest.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Lock_rTest.DownBack = null;
            this.skinButton_MB_Lock_rTest.Location = new System.Drawing.Point(445, 275);
            this.skinButton_MB_Lock_rTest.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Lock_rTest.MouseBack = null;
            this.skinButton_MB_Lock_rTest.Name = "skinButton_MB_Lock_rTest";
            this.skinButton_MB_Lock_rTest.NormlBack = null;
            this.skinButton_MB_Lock_rTest.Radius = 15;
            this.skinButton_MB_Lock_rTest.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Lock_rTest.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_Lock_rTest.TabIndex = 11;
            this.skinButton_MB_Lock_rTest.Text = "重新测试";
            this.skinButton_MB_Lock_rTest.UseVisualStyleBackColor = false;
            this.skinButton_MB_Lock_rTest.Click += new System.EventHandler(this.skinButton_MB_Lock_rTest_Click);
            // 
            // skinButton_MB_Lock_Skip
            // 
            this.skinButton_MB_Lock_Skip.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Lock_Skip.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Lock_Skip.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Lock_Skip.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Lock_Skip.DownBack = null;
            this.skinButton_MB_Lock_Skip.Location = new System.Drawing.Point(211, 275);
            this.skinButton_MB_Lock_Skip.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Lock_Skip.MouseBack = null;
            this.skinButton_MB_Lock_Skip.Name = "skinButton_MB_Lock_Skip";
            this.skinButton_MB_Lock_Skip.NormlBack = null;
            this.skinButton_MB_Lock_Skip.Radius = 15;
            this.skinButton_MB_Lock_Skip.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Lock_Skip.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_Lock_Skip.TabIndex = 10;
            this.skinButton_MB_Lock_Skip.Text = "跳过";
            this.skinButton_MB_Lock_Skip.UseVisualStyleBackColor = false;
            this.skinButton_MB_Lock_Skip.Click += new System.EventHandler(this.skinButton_MB_Lock_Skip_Click);
            // 
            // skinLabel_MB_Lock_Result
            // 
            this.skinLabel_MB_Lock_Result.AutoSize = true;
            this.skinLabel_MB_Lock_Result.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Lock_Result.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Lock_Result.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Lock_Result.Location = new System.Drawing.Point(211, 85);
            this.skinLabel_MB_Lock_Result.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Lock_Result.Name = "skinLabel_MB_Lock_Result";
            this.skinLabel_MB_Lock_Result.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Lock_Result.TabIndex = 40;
            // 
            // skinLabel14
            // 
            this.skinLabel14.AutoSize = true;
            this.skinLabel14.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel14.BorderColor = System.Drawing.Color.White;
            this.skinLabel14.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel14.Location = new System.Drawing.Point(60, 82);
            this.skinLabel14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel14.Name = "skinLabel14";
            this.skinLabel14.Size = new System.Drawing.Size(116, 31);
            this.skinLabel14.TabIndex = 3;
            this.skinLabel14.Text = "测试结果:";
            // 
            // skinTabPage_MB_PowerDown
            // 
            this.skinTabPage_MB_PowerDown.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_PowerDown.Controls.Add(this.skinSplitContainer5);
            this.skinTabPage_MB_PowerDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_PowerDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_PowerDown.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_PowerDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.skinTabPage_MB_PowerDown.Name = "skinTabPage_MB_PowerDown";
            this.skinTabPage_MB_PowerDown.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_PowerDown.TabIndex = 13;
            this.skinTabPage_MB_PowerDown.TabItemImage = null;
            this.skinTabPage_MB_PowerDown.Text = "掉电";
            // 
            // skinSplitContainer5
            // 
            this.skinSplitContainer5.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer5.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer5.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer5.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer5.Name = "skinSplitContainer5";
            this.skinSplitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer5.Panel1
            // 
            this.skinSplitContainer5.Panel1.Controls.Add(this.skinLabel12);
            this.skinSplitContainer5.Panel1.Controls.Add(this.skinLabel_MB_PowerDown_Time);
            this.skinSplitContainer5.Panel1.Controls.Add(this.skinLabel16);
            this.skinSplitContainer5.Panel1.Controls.Add(this.skinLabel17);
            this.skinSplitContainer5.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer5.Panel2
            // 
            this.skinSplitContainer5.Panel2.Controls.Add(this.skinButton_MB_PowerDown_Fail);
            this.skinSplitContainer5.Panel2.Controls.Add(this.skinButton_MB_PowerDown_Success);
            this.skinSplitContainer5.Panel2.Controls.Add(this.skinButton_MB_PowerDown_rTest);
            this.skinSplitContainer5.Panel2.Controls.Add(this.skinButton_MB_PowerDown_Skip);
            this.skinSplitContainer5.Panel2.Controls.Add(this.skinLabel_MB_PowerDown_Result);
            this.skinSplitContainer5.Panel2.Controls.Add(this.skinLabel19);
            this.skinSplitContainer5.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer5.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer5.SplitterDistance = 147;
            this.skinSplitContainer5.SplitterWidth = 5;
            this.skinSplitContainer5.TabIndex = 4;
            // 
            // skinLabel12
            // 
            this.skinLabel12.AutoSize = true;
            this.skinLabel12.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel12.BorderColor = System.Drawing.Color.White;
            this.skinLabel12.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel12.Location = new System.Drawing.Point(60, 86);
            this.skinLabel12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel12.Name = "skinLabel12";
            this.skinLabel12.Size = new System.Drawing.Size(254, 31);
            this.skinLabel12.TabIndex = 3;
            this.skinLabel12.Text = "测试前请先把电源关闭";
            // 
            // skinLabel_MB_PowerDown_Time
            // 
            this.skinLabel_MB_PowerDown_Time.AutoSize = true;
            this.skinLabel_MB_PowerDown_Time.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_PowerDown_Time.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_PowerDown_Time.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_PowerDown_Time.Location = new System.Drawing.Point(654, 28);
            this.skinLabel_MB_PowerDown_Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_PowerDown_Time.Name = "skinLabel_MB_PowerDown_Time";
            this.skinLabel_MB_PowerDown_Time.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_PowerDown_Time.TabIndex = 2;
            // 
            // skinLabel16
            // 
            this.skinLabel16.AutoSize = true;
            this.skinLabel16.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel16.BorderColor = System.Drawing.Color.White;
            this.skinLabel16.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel16.Location = new System.Drawing.Point(532, 28);
            this.skinLabel16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel16.Name = "skinLabel16";
            this.skinLabel16.Size = new System.Drawing.Size(92, 31);
            this.skinLabel16.TabIndex = 1;
            this.skinLabel16.Text = "倒计时:";
            // 
            // skinLabel17
            // 
            this.skinLabel17.AutoSize = true;
            this.skinLabel17.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel17.BorderColor = System.Drawing.Color.White;
            this.skinLabel17.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel17.Location = new System.Drawing.Point(60, 28);
            this.skinLabel17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel17.Name = "skinLabel17";
            this.skinLabel17.Size = new System.Drawing.Size(212, 31);
            this.skinLabel17.TabIndex = 0;
            this.skinLabel17.Text = "当前项目:掉电测试";
            // 
            // skinButton_MB_PowerDown_Fail
            // 
            this.skinButton_MB_PowerDown_Fail.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_PowerDown_Fail.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_Fail.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_Fail.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_PowerDown_Fail.DownBack = null;
            this.skinButton_MB_PowerDown_Fail.Location = new System.Drawing.Point(445, 144);
            this.skinButton_MB_PowerDown_Fail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_PowerDown_Fail.MouseBack = null;
            this.skinButton_MB_PowerDown_Fail.Name = "skinButton_MB_PowerDown_Fail";
            this.skinButton_MB_PowerDown_Fail.NormlBack = null;
            this.skinButton_MB_PowerDown_Fail.Radius = 15;
            this.skinButton_MB_PowerDown_Fail.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_PowerDown_Fail.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_PowerDown_Fail.TabIndex = 13;
            this.skinButton_MB_PowerDown_Fail.Text = "失败";
            this.skinButton_MB_PowerDown_Fail.UseVisualStyleBackColor = false;
            this.skinButton_MB_PowerDown_Fail.Click += new System.EventHandler(this.skinButton_MB_PowerDown_Fail_Click);
            // 
            // skinButton_MB_PowerDown_Success
            // 
            this.skinButton_MB_PowerDown_Success.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_PowerDown_Success.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_Success.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_Success.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_PowerDown_Success.DownBack = null;
            this.skinButton_MB_PowerDown_Success.Location = new System.Drawing.Point(211, 144);
            this.skinButton_MB_PowerDown_Success.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_PowerDown_Success.MouseBack = null;
            this.skinButton_MB_PowerDown_Success.Name = "skinButton_MB_PowerDown_Success";
            this.skinButton_MB_PowerDown_Success.NormlBack = null;
            this.skinButton_MB_PowerDown_Success.Radius = 15;
            this.skinButton_MB_PowerDown_Success.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_PowerDown_Success.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_PowerDown_Success.TabIndex = 12;
            this.skinButton_MB_PowerDown_Success.Text = "成功";
            this.skinButton_MB_PowerDown_Success.UseVisualStyleBackColor = false;
            this.skinButton_MB_PowerDown_Success.Click += new System.EventHandler(this.skinButton_MB_PowerDown_Success_Click);
            // 
            // skinButton_MB_PowerDown_rTest
            // 
            this.skinButton_MB_PowerDown_rTest.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_PowerDown_rTest.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_rTest.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_rTest.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_PowerDown_rTest.DownBack = null;
            this.skinButton_MB_PowerDown_rTest.Location = new System.Drawing.Point(445, 253);
            this.skinButton_MB_PowerDown_rTest.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_PowerDown_rTest.MouseBack = null;
            this.skinButton_MB_PowerDown_rTest.Name = "skinButton_MB_PowerDown_rTest";
            this.skinButton_MB_PowerDown_rTest.NormlBack = null;
            this.skinButton_MB_PowerDown_rTest.Radius = 15;
            this.skinButton_MB_PowerDown_rTest.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_PowerDown_rTest.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_PowerDown_rTest.TabIndex = 11;
            this.skinButton_MB_PowerDown_rTest.Text = "重新测试";
            this.skinButton_MB_PowerDown_rTest.UseVisualStyleBackColor = false;
            this.skinButton_MB_PowerDown_rTest.Click += new System.EventHandler(this.skinButton_MB_PowerDown_rTest_Click);
            // 
            // skinButton_MB_PowerDown_Skip
            // 
            this.skinButton_MB_PowerDown_Skip.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_PowerDown_Skip.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_Skip.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_PowerDown_Skip.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_PowerDown_Skip.DownBack = null;
            this.skinButton_MB_PowerDown_Skip.Location = new System.Drawing.Point(211, 253);
            this.skinButton_MB_PowerDown_Skip.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_PowerDown_Skip.MouseBack = null;
            this.skinButton_MB_PowerDown_Skip.Name = "skinButton_MB_PowerDown_Skip";
            this.skinButton_MB_PowerDown_Skip.NormlBack = null;
            this.skinButton_MB_PowerDown_Skip.Radius = 15;
            this.skinButton_MB_PowerDown_Skip.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_PowerDown_Skip.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_PowerDown_Skip.TabIndex = 10;
            this.skinButton_MB_PowerDown_Skip.Text = "跳过";
            this.skinButton_MB_PowerDown_Skip.UseVisualStyleBackColor = false;
            this.skinButton_MB_PowerDown_Skip.Click += new System.EventHandler(this.skinButton_MB_PowerDown_Skip_Click);
            // 
            // skinLabel_MB_PowerDown_Result
            // 
            this.skinLabel_MB_PowerDown_Result.AutoSize = true;
            this.skinLabel_MB_PowerDown_Result.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_PowerDown_Result.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_PowerDown_Result.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_PowerDown_Result.Location = new System.Drawing.Point(211, 30);
            this.skinLabel_MB_PowerDown_Result.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_PowerDown_Result.Name = "skinLabel_MB_PowerDown_Result";
            this.skinLabel_MB_PowerDown_Result.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_PowerDown_Result.TabIndex = 4;
            // 
            // skinLabel19
            // 
            this.skinLabel19.AutoSize = true;
            this.skinLabel19.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel19.BorderColor = System.Drawing.Color.White;
            this.skinLabel19.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel19.Location = new System.Drawing.Point(60, 27);
            this.skinLabel19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel19.Name = "skinLabel19";
            this.skinLabel19.Size = new System.Drawing.Size(116, 31);
            this.skinLabel19.TabIndex = 3;
            this.skinLabel19.Text = "测试结果:";
            // 
            // skinTabPage_MB_Battery
            // 
            this.skinTabPage_MB_Battery.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_Battery.Controls.Add(this.skinSplitContainer6);
            this.skinTabPage_MB_Battery.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_Battery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_Battery.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_Battery.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.skinTabPage_MB_Battery.Name = "skinTabPage_MB_Battery";
            this.skinTabPage_MB_Battery.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_Battery.TabIndex = 14;
            this.skinTabPage_MB_Battery.TabItemImage = null;
            this.skinTabPage_MB_Battery.Text = "电池";
            // 
            // skinSplitContainer6
            // 
            this.skinSplitContainer6.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer6.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer6.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer6.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer6.Name = "skinSplitContainer6";
            this.skinSplitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer6.Panel1
            // 
            this.skinSplitContainer6.Panel1.Controls.Add(this.skinLabel_MB_Battery_Time);
            this.skinSplitContainer6.Panel1.Controls.Add(this.skinLabel18);
            this.skinSplitContainer6.Panel1.Controls.Add(this.skinLabel20);
            this.skinSplitContainer6.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer6.Panel2
            // 
            this.skinSplitContainer6.Panel2.Controls.Add(this.skinButton_MB_Battery_rTest);
            this.skinSplitContainer6.Panel2.Controls.Add(this.skinButton_MB_Battery_Skip);
            this.skinSplitContainer6.Panel2.Controls.Add(this.skinLabel_MB_Battery_Result);
            this.skinSplitContainer6.Panel2.Controls.Add(this.skinLabel24);
            this.skinSplitContainer6.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer6.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer6.SplitterDistance = 73;
            this.skinSplitContainer6.SplitterWidth = 5;
            this.skinSplitContainer6.TabIndex = 5;
            // 
            // skinLabel_MB_Battery_Time
            // 
            this.skinLabel_MB_Battery_Time.AutoSize = true;
            this.skinLabel_MB_Battery_Time.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Battery_Time.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Battery_Time.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Battery_Time.Location = new System.Drawing.Point(654, 28);
            this.skinLabel_MB_Battery_Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Battery_Time.Name = "skinLabel_MB_Battery_Time";
            this.skinLabel_MB_Battery_Time.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Battery_Time.TabIndex = 2;
            // 
            // skinLabel18
            // 
            this.skinLabel18.AutoSize = true;
            this.skinLabel18.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel18.BorderColor = System.Drawing.Color.White;
            this.skinLabel18.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel18.Location = new System.Drawing.Point(532, 28);
            this.skinLabel18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel18.Name = "skinLabel18";
            this.skinLabel18.Size = new System.Drawing.Size(92, 31);
            this.skinLabel18.TabIndex = 1;
            this.skinLabel18.Text = "倒计时:";
            // 
            // skinLabel20
            // 
            this.skinLabel20.AutoSize = true;
            this.skinLabel20.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel20.BorderColor = System.Drawing.Color.White;
            this.skinLabel20.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel20.Location = new System.Drawing.Point(60, 28);
            this.skinLabel20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel20.Name = "skinLabel20";
            this.skinLabel20.Size = new System.Drawing.Size(212, 31);
            this.skinLabel20.TabIndex = 0;
            this.skinLabel20.Text = "当前项目:电池检测";
            // 
            // skinButton_MB_Battery_rTest
            // 
            this.skinButton_MB_Battery_rTest.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Battery_rTest.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Battery_rTest.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Battery_rTest.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Battery_rTest.DownBack = null;
            this.skinButton_MB_Battery_rTest.Location = new System.Drawing.Point(455, 218);
            this.skinButton_MB_Battery_rTest.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Battery_rTest.MouseBack = null;
            this.skinButton_MB_Battery_rTest.Name = "skinButton_MB_Battery_rTest";
            this.skinButton_MB_Battery_rTest.NormlBack = null;
            this.skinButton_MB_Battery_rTest.Radius = 15;
            this.skinButton_MB_Battery_rTest.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Battery_rTest.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_Battery_rTest.TabIndex = 11;
            this.skinButton_MB_Battery_rTest.Text = "重新测试";
            this.skinButton_MB_Battery_rTest.UseVisualStyleBackColor = false;
            this.skinButton_MB_Battery_rTest.Click += new System.EventHandler(this.skinButton_MB_Battery_rTest_Click);
            // 
            // skinButton_MB_Battery_Skip
            // 
            this.skinButton_MB_Battery_Skip.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_MB_Battery_Skip.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Battery_Skip.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_MB_Battery_Skip.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_MB_Battery_Skip.DownBack = null;
            this.skinButton_MB_Battery_Skip.Location = new System.Drawing.Point(220, 218);
            this.skinButton_MB_Battery_Skip.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_MB_Battery_Skip.MouseBack = null;
            this.skinButton_MB_Battery_Skip.Name = "skinButton_MB_Battery_Skip";
            this.skinButton_MB_Battery_Skip.NormlBack = null;
            this.skinButton_MB_Battery_Skip.Radius = 15;
            this.skinButton_MB_Battery_Skip.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_MB_Battery_Skip.Size = new System.Drawing.Size(179, 50);
            this.skinButton_MB_Battery_Skip.TabIndex = 10;
            this.skinButton_MB_Battery_Skip.Text = "跳过";
            this.skinButton_MB_Battery_Skip.UseVisualStyleBackColor = false;
            this.skinButton_MB_Battery_Skip.Click += new System.EventHandler(this.skinButton_MB_Battery_Skip_Click);
            // 
            // skinLabel_MB_Battery_Result
            // 
            this.skinLabel_MB_Battery_Result.AutoSize = true;
            this.skinLabel_MB_Battery_Result.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_MB_Battery_Result.BorderColor = System.Drawing.Color.White;
            this.skinLabel_MB_Battery_Result.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_MB_Battery_Result.Location = new System.Drawing.Point(211, 30);
            this.skinLabel_MB_Battery_Result.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel_MB_Battery_Result.Name = "skinLabel_MB_Battery_Result";
            this.skinLabel_MB_Battery_Result.Size = new System.Drawing.Size(0, 31);
            this.skinLabel_MB_Battery_Result.TabIndex = 40;
            // 
            // skinLabel24
            // 
            this.skinLabel24.AutoSize = true;
            this.skinLabel24.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel24.BorderColor = System.Drawing.Color.White;
            this.skinLabel24.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel24.Location = new System.Drawing.Point(60, 27);
            this.skinLabel24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel24.Name = "skinLabel24";
            this.skinLabel24.Size = new System.Drawing.Size(116, 31);
            this.skinLabel24.TabIndex = 3;
            this.skinLabel24.Text = "测试结果:";
            // 
            // skinTabPage_MB_STOPTEST
            // 
            this.skinTabPage_MB_STOPTEST.BackColor = System.Drawing.Color.White;
            this.skinTabPage_MB_STOPTEST.Controls.Add(this.skinSplitContainer19);
            this.skinTabPage_MB_STOPTEST.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_MB_STOPTEST.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTabPage_MB_STOPTEST.Location = new System.Drawing.Point(100, 0);
            this.skinTabPage_MB_STOPTEST.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabPage_MB_STOPTEST.Name = "skinTabPage_MB_STOPTEST";
            this.skinTabPage_MB_STOPTEST.Size = new System.Drawing.Size(948, 679);
            this.skinTabPage_MB_STOPTEST.TabIndex = 8;
            this.skinTabPage_MB_STOPTEST.TabItemImage = null;
            this.skinTabPage_MB_STOPTEST.Text = "结束测试";
            // 
            // skinSplitContainer19
            // 
            this.skinSplitContainer19.Cursor = System.Windows.Forms.Cursors.Default;
            this.skinSplitContainer19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinSplitContainer19.LineBack = System.Drawing.Color.Gray;
            this.skinSplitContainer19.LineBack2 = System.Drawing.Color.Gray;
            this.skinSplitContainer19.Location = new System.Drawing.Point(0, 0);
            this.skinSplitContainer19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinSplitContainer19.Name = "skinSplitContainer19";
            this.skinSplitContainer19.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // skinSplitContainer19.Panel1
            // 
            this.skinSplitContainer19.Panel1.Controls.Add(this.skinLabel15);
            this.skinSplitContainer19.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // skinSplitContainer19.Panel2
            // 
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_TEMP_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.skinLabel21);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_POWER_DOWN_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.skinLabel60);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_BATTERY_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.skinLabel22);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_TEST_START_TIME);
            this.skinSplitContainer19.Panel2.Controls.Add(this.skinLabel85);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_TEST_USED_TIME_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_LOCK_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_BT_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_POWER_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_ALL_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_FW_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_TESTOR_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_PCB_RESULT_VAL);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_TEST_USED_TIME);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_FLASH_RESULT);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_LED_RESULT);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_POWER_RESULT);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_ALL_RESULT);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_FW_RESULT);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_TESTOR_RESULT);
            this.skinSplitContainer19.Panel2.Controls.Add(this.MB_PCB_RESULT);
            this.skinSplitContainer19.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.skinSplitContainer19.Size = new System.Drawing.Size(948, 679);
            this.skinSplitContainer19.SplitterDistance = 62;
            this.skinSplitContainer19.SplitterWidth = 5;
            this.skinSplitContainer19.TabIndex = 2;
            // 
            // skinLabel15
            // 
            this.skinLabel15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinLabel15.AutoEllipsis = true;
            this.skinLabel15.AutoSize = true;
            this.skinLabel15.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel15.BorderColor = System.Drawing.Color.White;
            this.skinLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel15.Location = new System.Drawing.Point(343, 18);
            this.skinLabel15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel15.Name = "skinLabel15";
            this.skinLabel15.Size = new System.Drawing.Size(122, 31);
            this.skinLabel15.TabIndex = 15;
            this.skinLabel15.Text = "测试结果";
            // 
            // MB_TEMP_RESULT_VAL
            // 
            this.MB_TEMP_RESULT_VAL.AllowDrop = true;
            this.MB_TEMP_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_TEMP_RESULT_VAL.AutoEllipsis = true;
            this.MB_TEMP_RESULT_VAL.AutoSize = true;
            this.MB_TEMP_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_TEMP_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_TEMP_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_TEMP_RESULT_VAL.Location = new System.Drawing.Point(544, 212);
            this.MB_TEMP_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_TEMP_RESULT_VAL.Name = "MB_TEMP_RESULT_VAL";
            this.MB_TEMP_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_TEMP_RESULT_VAL.TabIndex = 68;
            this.MB_TEMP_RESULT_VAL.Text = "  ";
            // 
            // skinLabel21
            // 
            this.skinLabel21.AllowDrop = true;
            this.skinLabel21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinLabel21.AutoEllipsis = true;
            this.skinLabel21.AutoSize = true;
            this.skinLabel21.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel21.BorderColor = System.Drawing.Color.White;
            this.skinLabel21.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel21.Location = new System.Drawing.Point(190, 212);
            this.skinLabel21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel21.Name = "skinLabel21";
            this.skinLabel21.Size = new System.Drawing.Size(82, 31);
            this.skinLabel21.TabIndex = 67;
            this.skinLabel21.Text = "  温度:";
            // 
            // MB_POWER_DOWN_RESULT_VAL
            // 
            this.MB_POWER_DOWN_RESULT_VAL.AllowDrop = true;
            this.MB_POWER_DOWN_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_POWER_DOWN_RESULT_VAL.AutoEllipsis = true;
            this.MB_POWER_DOWN_RESULT_VAL.AutoSize = true;
            this.MB_POWER_DOWN_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_POWER_DOWN_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_POWER_DOWN_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_POWER_DOWN_RESULT_VAL.Location = new System.Drawing.Point(544, 279);
            this.MB_POWER_DOWN_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_POWER_DOWN_RESULT_VAL.Name = "MB_POWER_DOWN_RESULT_VAL";
            this.MB_POWER_DOWN_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_POWER_DOWN_RESULT_VAL.TabIndex = 66;
            this.MB_POWER_DOWN_RESULT_VAL.Text = "  ";
            // 
            // skinLabel60
            // 
            this.skinLabel60.AllowDrop = true;
            this.skinLabel60.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinLabel60.AutoEllipsis = true;
            this.skinLabel60.AutoSize = true;
            this.skinLabel60.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel60.BorderColor = System.Drawing.Color.White;
            this.skinLabel60.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel60.Location = new System.Drawing.Point(190, 279);
            this.skinLabel60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel60.Name = "skinLabel60";
            this.skinLabel60.Size = new System.Drawing.Size(82, 31);
            this.skinLabel60.TabIndex = 65;
            this.skinLabel60.Text = "  掉电:";
            // 
            // MB_BATTERY_RESULT_VAL
            // 
            this.MB_BATTERY_RESULT_VAL.AllowDrop = true;
            this.MB_BATTERY_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_BATTERY_RESULT_VAL.AutoEllipsis = true;
            this.MB_BATTERY_RESULT_VAL.AutoSize = true;
            this.MB_BATTERY_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_BATTERY_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_BATTERY_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_BATTERY_RESULT_VAL.Location = new System.Drawing.Point(544, 312);
            this.MB_BATTERY_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_BATTERY_RESULT_VAL.Name = "MB_BATTERY_RESULT_VAL";
            this.MB_BATTERY_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_BATTERY_RESULT_VAL.TabIndex = 56;
            this.MB_BATTERY_RESULT_VAL.Text = "  ";
            // 
            // skinLabel22
            // 
            this.skinLabel22.AllowDrop = true;
            this.skinLabel22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinLabel22.AutoEllipsis = true;
            this.skinLabel22.AutoSize = true;
            this.skinLabel22.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel22.BorderColor = System.Drawing.Color.White;
            this.skinLabel22.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel22.Location = new System.Drawing.Point(190, 312);
            this.skinLabel22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel22.Name = "skinLabel22";
            this.skinLabel22.Size = new System.Drawing.Size(82, 31);
            this.skinLabel22.TabIndex = 55;
            this.skinLabel22.Text = "  电池:";
            // 
            // MB_TEST_START_TIME
            // 
            this.MB_TEST_START_TIME.AllowDrop = true;
            this.MB_TEST_START_TIME.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_TEST_START_TIME.AutoEllipsis = true;
            this.MB_TEST_START_TIME.AutoSize = true;
            this.MB_TEST_START_TIME.BackColor = System.Drawing.Color.Transparent;
            this.MB_TEST_START_TIME.BorderColor = System.Drawing.Color.White;
            this.MB_TEST_START_TIME.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_TEST_START_TIME.Location = new System.Drawing.Point(544, 379);
            this.MB_TEST_START_TIME.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_TEST_START_TIME.Name = "MB_TEST_START_TIME";
            this.MB_TEST_START_TIME.Size = new System.Drawing.Size(28, 31);
            this.MB_TEST_START_TIME.TabIndex = 54;
            this.MB_TEST_START_TIME.Text = "  ";
            // 
            // skinLabel85
            // 
            this.skinLabel85.AllowDrop = true;
            this.skinLabel85.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinLabel85.AutoEllipsis = true;
            this.skinLabel85.AutoSize = true;
            this.skinLabel85.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel85.BorderColor = System.Drawing.Color.White;
            this.skinLabel85.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel85.Location = new System.Drawing.Point(139, 379);
            this.skinLabel85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.skinLabel85.Name = "skinLabel85";
            this.skinLabel85.Size = new System.Drawing.Size(130, 31);
            this.skinLabel85.TabIndex = 53;
            this.skinLabel85.Text = "  测试时间:";
            // 
            // MB_TEST_USED_TIME_VAL
            // 
            this.MB_TEST_USED_TIME_VAL.AllowDrop = true;
            this.MB_TEST_USED_TIME_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_TEST_USED_TIME_VAL.AutoEllipsis = true;
            this.MB_TEST_USED_TIME_VAL.AutoSize = true;
            this.MB_TEST_USED_TIME_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_TEST_USED_TIME_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_TEST_USED_TIME_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_TEST_USED_TIME_VAL.Location = new System.Drawing.Point(544, 346);
            this.MB_TEST_USED_TIME_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_TEST_USED_TIME_VAL.Name = "MB_TEST_USED_TIME_VAL";
            this.MB_TEST_USED_TIME_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_TEST_USED_TIME_VAL.TabIndex = 52;
            this.MB_TEST_USED_TIME_VAL.Text = "  ";
            // 
            // MB_LOCK_RESULT_VAL
            // 
            this.MB_LOCK_RESULT_VAL.AllowDrop = true;
            this.MB_LOCK_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_LOCK_RESULT_VAL.AutoEllipsis = true;
            this.MB_LOCK_RESULT_VAL.AutoSize = true;
            this.MB_LOCK_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_LOCK_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_LOCK_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_LOCK_RESULT_VAL.Location = new System.Drawing.Point(544, 246);
            this.MB_LOCK_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_LOCK_RESULT_VAL.Name = "MB_LOCK_RESULT_VAL";
            this.MB_LOCK_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_LOCK_RESULT_VAL.TabIndex = 49;
            this.MB_LOCK_RESULT_VAL.Text = "  ";
            // 
            // MB_BT_RESULT_VAL
            // 
            this.MB_BT_RESULT_VAL.AllowDrop = true;
            this.MB_BT_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_BT_RESULT_VAL.AutoEllipsis = true;
            this.MB_BT_RESULT_VAL.AutoSize = true;
            this.MB_BT_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_BT_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_BT_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_BT_RESULT_VAL.Location = new System.Drawing.Point(544, 179);
            this.MB_BT_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_BT_RESULT_VAL.Name = "MB_BT_RESULT_VAL";
            this.MB_BT_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_BT_RESULT_VAL.TabIndex = 45;
            this.MB_BT_RESULT_VAL.Text = "  ";
            // 
            // MB_POWER_RESULT_VAL
            // 
            this.MB_POWER_RESULT_VAL.AllowDrop = true;
            this.MB_POWER_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_POWER_RESULT_VAL.AutoEllipsis = true;
            this.MB_POWER_RESULT_VAL.AutoSize = true;
            this.MB_POWER_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_POWER_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_POWER_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_POWER_RESULT_VAL.Location = new System.Drawing.Point(544, 146);
            this.MB_POWER_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_POWER_RESULT_VAL.Name = "MB_POWER_RESULT_VAL";
            this.MB_POWER_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_POWER_RESULT_VAL.TabIndex = 44;
            this.MB_POWER_RESULT_VAL.Text = "  ";
            // 
            // MB_ALL_RESULT_VAL
            // 
            this.MB_ALL_RESULT_VAL.AllowDrop = true;
            this.MB_ALL_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_ALL_RESULT_VAL.AutoEllipsis = true;
            this.MB_ALL_RESULT_VAL.AutoSize = true;
            this.MB_ALL_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_ALL_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_ALL_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_ALL_RESULT_VAL.Location = new System.Drawing.Point(544, 112);
            this.MB_ALL_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_ALL_RESULT_VAL.Name = "MB_ALL_RESULT_VAL";
            this.MB_ALL_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_ALL_RESULT_VAL.TabIndex = 43;
            this.MB_ALL_RESULT_VAL.Text = "  ";
            // 
            // MB_FW_RESULT_VAL
            // 
            this.MB_FW_RESULT_VAL.AllowDrop = true;
            this.MB_FW_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_FW_RESULT_VAL.AutoEllipsis = true;
            this.MB_FW_RESULT_VAL.AutoSize = true;
            this.MB_FW_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_FW_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_FW_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_FW_RESULT_VAL.Location = new System.Drawing.Point(544, 79);
            this.MB_FW_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_FW_RESULT_VAL.Name = "MB_FW_RESULT_VAL";
            this.MB_FW_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_FW_RESULT_VAL.TabIndex = 42;
            this.MB_FW_RESULT_VAL.Text = "  ";
            // 
            // MB_TESTOR_RESULT_VAL
            // 
            this.MB_TESTOR_RESULT_VAL.AllowDrop = true;
            this.MB_TESTOR_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_TESTOR_RESULT_VAL.AutoEllipsis = true;
            this.MB_TESTOR_RESULT_VAL.AutoSize = true;
            this.MB_TESTOR_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_TESTOR_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_TESTOR_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_TESTOR_RESULT_VAL.Location = new System.Drawing.Point(544, 46);
            this.MB_TESTOR_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_TESTOR_RESULT_VAL.Name = "MB_TESTOR_RESULT_VAL";
            this.MB_TESTOR_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_TESTOR_RESULT_VAL.TabIndex = 41;
            this.MB_TESTOR_RESULT_VAL.Text = "  ";
            // 
            // MB_PCB_RESULT_VAL
            // 
            this.MB_PCB_RESULT_VAL.AllowDrop = true;
            this.MB_PCB_RESULT_VAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_PCB_RESULT_VAL.AutoEllipsis = true;
            this.MB_PCB_RESULT_VAL.AutoSize = true;
            this.MB_PCB_RESULT_VAL.BackColor = System.Drawing.Color.Transparent;
            this.MB_PCB_RESULT_VAL.BorderColor = System.Drawing.Color.White;
            this.MB_PCB_RESULT_VAL.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_PCB_RESULT_VAL.Location = new System.Drawing.Point(544, 12);
            this.MB_PCB_RESULT_VAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_PCB_RESULT_VAL.Name = "MB_PCB_RESULT_VAL";
            this.MB_PCB_RESULT_VAL.Size = new System.Drawing.Size(28, 31);
            this.MB_PCB_RESULT_VAL.TabIndex = 40;
            this.MB_PCB_RESULT_VAL.Text = "  ";
            // 
            // MB_TEST_USED_TIME
            // 
            this.MB_TEST_USED_TIME.AllowDrop = true;
            this.MB_TEST_USED_TIME.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_TEST_USED_TIME.AutoEllipsis = true;
            this.MB_TEST_USED_TIME.AutoSize = true;
            this.MB_TEST_USED_TIME.BackColor = System.Drawing.Color.Transparent;
            this.MB_TEST_USED_TIME.BorderColor = System.Drawing.Color.White;
            this.MB_TEST_USED_TIME.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_TEST_USED_TIME.Location = new System.Drawing.Point(139, 346);
            this.MB_TEST_USED_TIME.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_TEST_USED_TIME.Name = "MB_TEST_USED_TIME";
            this.MB_TEST_USED_TIME.Size = new System.Drawing.Size(130, 31);
            this.MB_TEST_USED_TIME.TabIndex = 39;
            this.MB_TEST_USED_TIME.Text = "  测试用时:";
            // 
            // MB_FLASH_RESULT
            // 
            this.MB_FLASH_RESULT.AllowDrop = true;
            this.MB_FLASH_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_FLASH_RESULT.AutoEllipsis = true;
            this.MB_FLASH_RESULT.AutoSize = true;
            this.MB_FLASH_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_FLASH_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_FLASH_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_FLASH_RESULT.Location = new System.Drawing.Point(190, 246);
            this.MB_FLASH_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_FLASH_RESULT.Name = "MB_FLASH_RESULT";
            this.MB_FLASH_RESULT.Size = new System.Drawing.Size(82, 31);
            this.MB_FLASH_RESULT.TabIndex = 36;
            this.MB_FLASH_RESULT.Text = "  柜锁:";
            // 
            // MB_LED_RESULT
            // 
            this.MB_LED_RESULT.AllowDrop = true;
            this.MB_LED_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_LED_RESULT.AutoEllipsis = true;
            this.MB_LED_RESULT.AutoSize = true;
            this.MB_LED_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_LED_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_LED_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_LED_RESULT.Location = new System.Drawing.Point(190, 179);
            this.MB_LED_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_LED_RESULT.Name = "MB_LED_RESULT";
            this.MB_LED_RESULT.Size = new System.Drawing.Size(82, 31);
            this.MB_LED_RESULT.TabIndex = 32;
            this.MB_LED_RESULT.Text = "  蓝牙:";
            // 
            // MB_POWER_RESULT
            // 
            this.MB_POWER_RESULT.AllowDrop = true;
            this.MB_POWER_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_POWER_RESULT.AutoEllipsis = true;
            this.MB_POWER_RESULT.AutoSize = true;
            this.MB_POWER_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_POWER_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_POWER_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_POWER_RESULT.Location = new System.Drawing.Point(190, 146);
            this.MB_POWER_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_POWER_RESULT.Name = "MB_POWER_RESULT";
            this.MB_POWER_RESULT.Size = new System.Drawing.Size(82, 31);
            this.MB_POWER_RESULT.TabIndex = 31;
            this.MB_POWER_RESULT.Text = "  电源:";
            // 
            // MB_ALL_RESULT
            // 
            this.MB_ALL_RESULT.AllowDrop = true;
            this.MB_ALL_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_ALL_RESULT.AutoEllipsis = true;
            this.MB_ALL_RESULT.AutoSize = true;
            this.MB_ALL_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_ALL_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_ALL_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_ALL_RESULT.Location = new System.Drawing.Point(139, 112);
            this.MB_ALL_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_ALL_RESULT.Name = "MB_ALL_RESULT";
            this.MB_ALL_RESULT.Size = new System.Drawing.Size(130, 31);
            this.MB_ALL_RESULT.TabIndex = 30;
            this.MB_ALL_RESULT.Text = "  测试结果:";
            // 
            // MB_FW_RESULT
            // 
            this.MB_FW_RESULT.AllowDrop = true;
            this.MB_FW_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_FW_RESULT.AutoEllipsis = true;
            this.MB_FW_RESULT.AutoSize = true;
            this.MB_FW_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_FW_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_FW_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_FW_RESULT.Location = new System.Drawing.Point(139, 79);
            this.MB_FW_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_FW_RESULT.Name = "MB_FW_RESULT";
            this.MB_FW_RESULT.Size = new System.Drawing.Size(130, 31);
            this.MB_FW_RESULT.TabIndex = 29;
            this.MB_FW_RESULT.Text = "  软件版本:";
            // 
            // MB_TESTOR_RESULT
            // 
            this.MB_TESTOR_RESULT.AllowDrop = true;
            this.MB_TESTOR_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_TESTOR_RESULT.AutoEllipsis = true;
            this.MB_TESTOR_RESULT.AutoSize = true;
            this.MB_TESTOR_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_TESTOR_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_TESTOR_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_TESTOR_RESULT.Location = new System.Drawing.Point(164, 46);
            this.MB_TESTOR_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_TESTOR_RESULT.Name = "MB_TESTOR_RESULT";
            this.MB_TESTOR_RESULT.Size = new System.Drawing.Size(106, 31);
            this.MB_TESTOR_RESULT.TabIndex = 28;
            this.MB_TESTOR_RESULT.Text = "  测试员:";
            // 
            // MB_PCB_RESULT
            // 
            this.MB_PCB_RESULT.AllowDrop = true;
            this.MB_PCB_RESULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MB_PCB_RESULT.AutoEllipsis = true;
            this.MB_PCB_RESULT.AutoSize = true;
            this.MB_PCB_RESULT.BackColor = System.Drawing.Color.Transparent;
            this.MB_PCB_RESULT.BorderColor = System.Drawing.Color.White;
            this.MB_PCB_RESULT.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MB_PCB_RESULT.Location = new System.Drawing.Point(141, 12);
            this.MB_PCB_RESULT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MB_PCB_RESULT.Name = "MB_PCB_RESULT";
            this.MB_PCB_RESULT.Size = new System.Drawing.Size(128, 31);
            this.MB_PCB_RESULT.TabIndex = 27;
            this.MB_PCB_RESULT.Text = "  PCB编号:";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 548F));
            this.tableLayoutPanel2.Controls.Add(this.skinButton_PCBA_CLEAR_LOG, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBoxDebug, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(1060, 3);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(492, 679);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // skinButton_PCBA_CLEAR_LOG
            // 
            this.skinButton_PCBA_CLEAR_LOG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.skinButton_PCBA_CLEAR_LOG.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_PCBA_CLEAR_LOG.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton_PCBA_CLEAR_LOG.BorderColor = System.Drawing.Color.DarkGray;
            this.skinButton_PCBA_CLEAR_LOG.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_PCBA_CLEAR_LOG.DownBack = null;
            this.skinButton_PCBA_CLEAR_LOG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton_PCBA_CLEAR_LOG.ForeColorSuit = true;
            this.skinButton_PCBA_CLEAR_LOG.Location = new System.Drawing.Point(4, 5);
            this.skinButton_PCBA_CLEAR_LOG.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_PCBA_CLEAR_LOG.MouseBack = null;
            this.skinButton_PCBA_CLEAR_LOG.Name = "skinButton_PCBA_CLEAR_LOG";
            this.skinButton_PCBA_CLEAR_LOG.NormlBack = null;
            this.skinButton_PCBA_CLEAR_LOG.Radius = 15;
            this.skinButton_PCBA_CLEAR_LOG.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_PCBA_CLEAR_LOG.Size = new System.Drawing.Size(187, 57);
            this.skinButton_PCBA_CLEAR_LOG.TabIndex = 5;
            this.skinButton_PCBA_CLEAR_LOG.Text = "清除";
            this.skinButton_PCBA_CLEAR_LOG.UseVisualStyleBackColor = false;
            this.skinButton_PCBA_CLEAR_LOG.Click += new System.EventHandler(this.skinButton_PCBA_CLEAR_LOG_Click);
            // 
            // textBoxDebug
            // 
            this.textBoxDebug.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxDebug.Location = new System.Drawing.Point(4, 68);
            this.textBoxDebug.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBoxDebug.Multiline = true;
            this.textBoxDebug.Name = "textBoxDebug";
            this.textBoxDebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDebug.Size = new System.Drawing.Size(483, 608);
            this.textBoxDebug.TabIndex = 6;
            // 
            // skinTabPage_Config
            // 
            this.skinTabPage_Config.BackColor = System.Drawing.Color.White;
            this.skinTabPage_Config.Controls.Add(this.tableLayoutPanelSerialSetting);
            this.skinTabPage_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTabPage_Config.Location = new System.Drawing.Point(0, 100);
            this.skinTabPage_Config.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinTabPage_Config.Name = "skinTabPage_Config";
            this.skinTabPage_Config.Size = new System.Drawing.Size(1556, 685);
            this.skinTabPage_Config.TabIndex = 2;
            this.skinTabPage_Config.TabItemImage = null;
            this.skinTabPage_Config.Text = "测试配置";
            // 
            // tableLayoutPanelSerialSetting
            // 
            this.tableLayoutPanelSerialSetting.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanelSerialSetting.BackColor = System.Drawing.Color.OldLace;
            this.tableLayoutPanelSerialSetting.ColumnCount = 5;
            this.tableLayoutPanelSerialSetting.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelSerialSetting.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 238F));
            this.tableLayoutPanelSerialSetting.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 311F));
            this.tableLayoutPanelSerialSetting.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 344F));
            this.tableLayoutPanelSerialSetting.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 307F));
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label9, 1, 10);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label7, 1, 8);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label6, 1, 7);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.numericUpDownTestWaittime, 2, 8);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.tableLayoutPanel1, 2, 10);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.tableLayoutPanel3, 3, 10);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.comboBox_ChargerModel, 2, 7);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label5, 2, 6);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label2, 1, 4);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label1, 1, 3);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label3, 1, 2);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.skinButton_SerialCtrl, 2, 4);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.skinComboBox_BandRate, 2, 3);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.skinComboBox_SerialPortNum, 2, 2);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.label4, 2, 1);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.skinButton_AccountSetting, 2, 14);
            this.tableLayoutPanelSerialSetting.Controls.Add(this.skinButton_SaveConfig, 2, 13);
            this.tableLayoutPanelSerialSetting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelSerialSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tableLayoutPanelSerialSetting.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelSerialSetting.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanelSerialSetting.Name = "tableLayoutPanelSerialSetting";
            this.tableLayoutPanelSerialSetting.RowCount = 16;
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.101695F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.118644F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666844F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.2F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanelSerialSetting.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanelSerialSetting.Size = new System.Drawing.Size(1556, 685);
            this.tableLayoutPanelSerialSetting.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(360, 438);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 25);
            this.label9.TabIndex = 15;
            this.label9.Text = "温度值范围：";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(360, 352);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(212, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "测试超时时间（秒）：";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(360, 309);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "电桩型号：";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericUpDownTestWaittime
            // 
            this.numericUpDownTestWaittime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDownTestWaittime.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numericUpDownTestWaittime.Location = new System.Drawing.Point(598, 349);
            this.numericUpDownTestWaittime.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.numericUpDownTestWaittime.Name = "numericUpDownTestWaittime";
            this.numericUpDownTestWaittime.Size = new System.Drawing.Size(303, 30);
            this.numericUpDownTestWaittime.TabIndex = 12;
            this.numericUpDownTestWaittime.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 171F));
            this.tableLayoutPanel1.Controls.Add(this.numericUpDown_TempLowerLimit, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(598, 432);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(303, 37);
            this.tableLayoutPanel1.TabIndex = 22;
            // 
            // numericUpDown_TempLowerLimit
            // 
            this.numericUpDown_TempLowerLimit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numericUpDown_TempLowerLimit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDown_TempLowerLimit.Location = new System.Drawing.Point(136, 3);
            this.numericUpDown_TempLowerLimit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.numericUpDown_TempLowerLimit.Name = "numericUpDown_TempLowerLimit";
            this.numericUpDown_TempLowerLimit.Size = new System.Drawing.Size(163, 30);
            this.numericUpDown_TempLowerLimit.TabIndex = 18;
            this.numericUpDown_TempLowerLimit.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(4, 6);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 25);
            this.label11.TabIndex = 19;
            this.label11.Text = "下限：";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 179F));
            this.tableLayoutPanel3.Controls.Add(this.numericUpDown_TempUpperLimit, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(909, 432);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(336, 37);
            this.tableLayoutPanel3.TabIndex = 23;
            // 
            // numericUpDown_TempUpperLimit
            // 
            this.numericUpDown_TempUpperLimit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numericUpDown_TempUpperLimit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDown_TempUpperLimit.Location = new System.Drawing.Point(161, 3);
            this.numericUpDown_TempUpperLimit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.numericUpDown_TempUpperLimit.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.numericUpDown_TempUpperLimit.Name = "numericUpDown_TempUpperLimit";
            this.numericUpDown_TempUpperLimit.Size = new System.Drawing.Size(171, 30);
            this.numericUpDown_TempUpperLimit.TabIndex = 18;
            this.numericUpDown_TempUpperLimit.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(4, 6);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 25);
            this.label12.TabIndex = 19;
            this.label12.Text = "上限：";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox_ChargerModel
            // 
            this.comboBox_ChargerModel.AutoCompleteCustomSource.AddRange(new string[] {
            "A10"});
            this.comboBox_ChargerModel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBox_ChargerModel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox_ChargerModel.FormattingEnabled = true;
            this.comboBox_ChargerModel.Items.AddRange(new object[] {
            "E8"});
            this.comboBox_ChargerModel.Location = new System.Drawing.Point(598, 303);
            this.comboBox_ChargerModel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_ChargerModel.Name = "comboBox_ChargerModel";
            this.comboBox_ChargerModel.Size = new System.Drawing.Size(303, 33);
            this.comboBox_ChargerModel.TabIndex = 10;
            this.comboBox_ChargerModel.Text = "E8";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(598, 262);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 29);
            this.label5.TabIndex = 9;
            this.label5.Text = "测试项设置：";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(360, 181);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "串口控制:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(360, 138);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "波特率：";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(360, 95);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "端口号：";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // skinButton_SerialCtrl
            // 
            this.skinButton_SerialCtrl.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_SerialCtrl.BaseColor = System.Drawing.Color.DeepSkyBlue;
            this.skinButton_SerialCtrl.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.skinButton_SerialCtrl.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_SerialCtrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinButton_SerialCtrl.DownBack = null;
            this.skinButton_SerialCtrl.ForeColor = System.Drawing.Color.Black;
            this.skinButton_SerialCtrl.Location = new System.Drawing.Point(598, 175);
            this.skinButton_SerialCtrl.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_SerialCtrl.MouseBack = null;
            this.skinButton_SerialCtrl.Name = "skinButton_SerialCtrl";
            this.skinButton_SerialCtrl.NormlBack = null;
            this.skinButton_SerialCtrl.Radius = 10;
            this.skinButton_SerialCtrl.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_SerialCtrl.Size = new System.Drawing.Size(303, 37);
            this.skinButton_SerialCtrl.TabIndex = 5;
            this.skinButton_SerialCtrl.Text = "打开串口";
            this.skinButton_SerialCtrl.UseVisualStyleBackColor = false;
            this.skinButton_SerialCtrl.Click += new System.EventHandler(this.skinButton_SerialCtrl_Click);
            // 
            // skinComboBox_BandRate
            // 
            this.skinComboBox_BandRate.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.skinComboBox_BandRate.BaseColor = System.Drawing.Color.Silver;
            this.skinComboBox_BandRate.BorderColor = System.Drawing.Color.Silver;
            this.skinComboBox_BandRate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinComboBox_BandRate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_BandRate.ForeColor = System.Drawing.Color.Black;
            this.skinComboBox_BandRate.FormattingEnabled = true;
            this.skinComboBox_BandRate.Items.AddRange(new object[] {
            "19200",
            "115200",
            "76800",
            "57600",
            "43000",
            "38400",
            "14400",
            "9600",
            "4800"});
            this.skinComboBox_BandRate.Location = new System.Drawing.Point(598, 132);
            this.skinComboBox_BandRate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinComboBox_BandRate.Name = "skinComboBox_BandRate";
            this.skinComboBox_BandRate.Size = new System.Drawing.Size(303, 31);
            this.skinComboBox_BandRate.TabIndex = 1;
            this.skinComboBox_BandRate.WaterText = "";
            this.skinComboBox_BandRate.SelectedIndexChanged += new System.EventHandler(this.skinComboBox_BandRate_SelectedIndexChanged);
            // 
            // skinComboBox_SerialPortNum
            // 
            this.skinComboBox_SerialPortNum.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.skinComboBox_SerialPortNum.BaseColor = System.Drawing.Color.Silver;
            this.skinComboBox_SerialPortNum.BorderColor = System.Drawing.Color.Silver;
            this.skinComboBox_SerialPortNum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinComboBox_SerialPortNum.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_SerialPortNum.ForeColor = System.Drawing.Color.Black;
            this.skinComboBox_SerialPortNum.FormattingEnabled = true;
            this.skinComboBox_SerialPortNum.Location = new System.Drawing.Point(598, 89);
            this.skinComboBox_SerialPortNum.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinComboBox_SerialPortNum.Name = "skinComboBox_SerialPortNum";
            this.skinComboBox_SerialPortNum.Size = new System.Drawing.Size(303, 31);
            this.skinComboBox_SerialPortNum.TabIndex = 0;
            this.skinComboBox_SerialPortNum.WaterText = "";
            this.skinComboBox_SerialPortNum.DropDown += new System.EventHandler(this.skinComboBox_SerialPortNum_DropDown);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(598, 50);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "串口设置：";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // skinButton_AccountSetting
            // 
            this.skinButton_AccountSetting.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_AccountSetting.BaseColor = System.Drawing.Color.DeepSkyBlue;
            this.skinButton_AccountSetting.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.skinButton_AccountSetting.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_AccountSetting.DownBack = null;
            this.skinButton_AccountSetting.ForeColor = System.Drawing.Color.Black;
            this.skinButton_AccountSetting.Location = new System.Drawing.Point(598, 608);
            this.skinButton_AccountSetting.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_AccountSetting.MouseBack = null;
            this.skinButton_AccountSetting.Name = "skinButton_AccountSetting";
            this.skinButton_AccountSetting.NormlBack = null;
            this.skinButton_AccountSetting.Radius = 10;
            this.skinButton_AccountSetting.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_AccountSetting.Size = new System.Drawing.Size(299, 37);
            this.skinButton_AccountSetting.TabIndex = 26;
            this.skinButton_AccountSetting.Text = "账号设置";
            this.skinButton_AccountSetting.UseVisualStyleBackColor = false;
            this.skinButton_AccountSetting.Visible = false;
            // 
            // skinButton_SaveConfig
            // 
            this.skinButton_SaveConfig.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_SaveConfig.BaseColor = System.Drawing.Color.DeepSkyBlue;
            this.skinButton_SaveConfig.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.skinButton_SaveConfig.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_SaveConfig.DownBack = null;
            this.skinButton_SaveConfig.ForeColor = System.Drawing.Color.Black;
            this.skinButton_SaveConfig.Location = new System.Drawing.Point(598, 561);
            this.skinButton_SaveConfig.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skinButton_SaveConfig.MouseBack = null;
            this.skinButton_SaveConfig.Name = "skinButton_SaveConfig";
            this.skinButton_SaveConfig.NormlBack = null;
            this.skinButton_SaveConfig.Radius = 10;
            this.skinButton_SaveConfig.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinButton_SaveConfig.Size = new System.Drawing.Size(299, 37);
            this.skinButton_SaveConfig.TabIndex = 17;
            this.skinButton_SaveConfig.Text = "保存设置";
            this.skinButton_SaveConfig.UseVisualStyleBackColor = false;
            this.skinButton_SaveConfig.Click += new System.EventHandler(this.skinButton_SaveConfig_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1572, 820);
            this.Controls.Add(this.skinTabControl_Menu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "MainForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "E8自动化产测软件V1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.skinTabControl_Menu.ResumeLayout(false);
            this.skinTabPage_PCBA.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.skinTabControl_MB.ResumeLayout(false);
            this.skinTabPage_MB_PCBANum.ResumeLayout(false);
            this.skinSplitContainer1.Panel1.ResumeLayout(false);
            this.skinSplitContainer1.Panel1.PerformLayout();
            this.skinSplitContainer1.Panel2.ResumeLayout(false);
            this.skinSplitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer1)).EndInit();
            this.skinSplitContainer1.ResumeLayout(false);
            this.skinTabPage_MB_Power.ResumeLayout(false);
            this.skinSplitContainer2.Panel1.ResumeLayout(false);
            this.skinSplitContainer2.Panel1.PerformLayout();
            this.skinSplitContainer2.Panel2.ResumeLayout(false);
            this.skinSplitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer2)).EndInit();
            this.skinSplitContainer2.ResumeLayout(false);
            this.skinTabPage_MB_BT.ResumeLayout(false);
            this.skinSplitContainer17.Panel1.ResumeLayout(false);
            this.skinSplitContainer17.Panel1.PerformLayout();
            this.skinSplitContainer17.Panel2.ResumeLayout(false);
            this.skinSplitContainer17.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer17)).EndInit();
            this.skinSplitContainer17.ResumeLayout(false);
            this.skinTabPage_MB_Temp.ResumeLayout(false);
            this.skinSplitContainer3.Panel1.ResumeLayout(false);
            this.skinSplitContainer3.Panel1.PerformLayout();
            this.skinSplitContainer3.Panel2.ResumeLayout(false);
            this.skinSplitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer3)).EndInit();
            this.skinSplitContainer3.ResumeLayout(false);
            this.skinTabPage_MB_Lock.ResumeLayout(false);
            this.skinSplitContainer4.Panel1.ResumeLayout(false);
            this.skinSplitContainer4.Panel1.PerformLayout();
            this.skinSplitContainer4.Panel2.ResumeLayout(false);
            this.skinSplitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer4)).EndInit();
            this.skinSplitContainer4.ResumeLayout(false);
            this.skinTabPage_MB_PowerDown.ResumeLayout(false);
            this.skinSplitContainer5.Panel1.ResumeLayout(false);
            this.skinSplitContainer5.Panel1.PerformLayout();
            this.skinSplitContainer5.Panel2.ResumeLayout(false);
            this.skinSplitContainer5.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer5)).EndInit();
            this.skinSplitContainer5.ResumeLayout(false);
            this.skinTabPage_MB_Battery.ResumeLayout(false);
            this.skinSplitContainer6.Panel1.ResumeLayout(false);
            this.skinSplitContainer6.Panel1.PerformLayout();
            this.skinSplitContainer6.Panel2.ResumeLayout(false);
            this.skinSplitContainer6.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer6)).EndInit();
            this.skinSplitContainer6.ResumeLayout(false);
            this.skinTabPage_MB_STOPTEST.ResumeLayout(false);
            this.skinSplitContainer19.Panel1.ResumeLayout(false);
            this.skinSplitContainer19.Panel1.PerformLayout();
            this.skinSplitContainer19.Panel2.ResumeLayout(false);
            this.skinSplitContainer19.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinSplitContainer19)).EndInit();
            this.skinSplitContainer19.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.skinTabPage_Config.ResumeLayout(false);
            this.tableLayoutPanelSerialSetting.ResumeLayout(false);
            this.tableLayoutPanelSerialSetting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTestWaittime)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TempLowerLimit)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TempUpperLimit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CCWin.SkinControl.SkinTabControl skinTabControl_Menu;
        private CCWin.SkinControl.SkinTabPage skinTabPage_PCBA;
        private CCWin.SkinControl.SkinTabPage skinTabPage_Config;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelSerialSetting;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownTestWaittime;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.NumericUpDown numericUpDown_TempLowerLimit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.NumericUpDown numericUpDown_TempUpperLimit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox_ChargerModel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private CCWin.SkinControl.SkinButton skinButton_SerialCtrl;
        private CCWin.SkinControl.SkinComboBox skinComboBox_BandRate;
        private CCWin.SkinControl.SkinComboBox skinComboBox_SerialPortNum;
        private System.Windows.Forms.Label label4;
        private CCWin.SkinControl.SkinButton skinButton_AccountSetting;
        private CCWin.SkinControl.SkinButton skinButton_SaveConfig;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private CCWin.SkinControl.SkinButton skinButton_PCBA_CLEAR_LOG;
        private System.Windows.Forms.TextBox textBoxDebug;
        private CCWin.SkinControl.SkinTabControl skinTabControl_MB;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_PCBANum;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer1;
        private CCWin.SkinControl.SkinLabel skinLabel_PCBANumTip;
        private CCWin.SkinControl.SkinButton skinButton_MB_Confirm;
        private CCWin.SkinControl.SkinLabel skinLabel_PCBANumStartTip;
        private System.Windows.Forms.TextBox textBox_MB_QRCode;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_Power;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer2;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_PowerTimeCountDown;
        private CCWin.SkinControl.SkinLabel skinLabel3;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_POWER_RESULT;
        private CCWin.SkinControl.SkinButton skinButton_MB_Power_rTest;
        private CCWin.SkinControl.SkinButton skinButton_MB_Power_Over;
        private CCWin.SkinControl.SkinButton skinButton_MB_Power_Fail;
        private CCWin.SkinControl.SkinLabel skinLabel4;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_BT;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer17;
        private CCWin.SkinControl.SkinLabel skinLabel5;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_BT_TIME;
        private CCWin.SkinControl.SkinLabel skinLabel50;
        private CCWin.SkinControl.SkinLabel skinLabel66;
        private CCWin.SkinControl.SkinButton skinButton_MB_BT_FAIL;
        private CCWin.SkinControl.SkinButton skinButton_MB_BT_SUCCESS;
        private CCWin.SkinControl.SkinButton skinButton_MB_BT_RETEST;
        private CCWin.SkinControl.SkinButton skinButton_MB_BT_SKIP;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_BT_RESULT;
        private CCWin.SkinControl.SkinLabel skinLabel68;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_Temp;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer3;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_TEMP_TIME;
        private CCWin.SkinControl.SkinLabel skinLabel8;
        private CCWin.SkinControl.SkinLabel skinLabel9;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Temp_Result1;
        private CCWin.SkinControl.SkinButton skinButton_MB_Temp_rTest;
        private CCWin.SkinControl.SkinButton skinButton_MB_Temp_Skip;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Temp_Result;
        private CCWin.SkinControl.SkinLabel skinLabel11;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_Lock;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer4;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Lock_Time;
        private CCWin.SkinControl.SkinLabel skinLabel7;
        private CCWin.SkinControl.SkinLabel skinLabel10;
        private CCWin.SkinControl.SkinLabel skinLabel6;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Lock_Result1;
        private CCWin.SkinControl.SkinButton skinButton_MB_Lock_rTest;
        private CCWin.SkinControl.SkinButton skinButton_MB_Lock_Skip;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Lock_Result;
        private CCWin.SkinControl.SkinLabel skinLabel14;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_PowerDown;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer5;
        private CCWin.SkinControl.SkinLabel skinLabel12;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_PowerDown_Time;
        private CCWin.SkinControl.SkinLabel skinLabel16;
        private CCWin.SkinControl.SkinLabel skinLabel17;
        private CCWin.SkinControl.SkinButton skinButton_MB_PowerDown_Fail;
        private CCWin.SkinControl.SkinButton skinButton_MB_PowerDown_Success;
        private CCWin.SkinControl.SkinButton skinButton_MB_PowerDown_rTest;
        private CCWin.SkinControl.SkinButton skinButton_MB_PowerDown_Skip;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_PowerDown_Result;
        private CCWin.SkinControl.SkinLabel skinLabel19;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_Battery;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer6;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Battery_Time;
        private CCWin.SkinControl.SkinLabel skinLabel18;
        private CCWin.SkinControl.SkinLabel skinLabel20;
        private CCWin.SkinControl.SkinButton skinButton_MB_Battery_rTest;
        private CCWin.SkinControl.SkinButton skinButton_MB_Battery_Skip;
        private CCWin.SkinControl.SkinLabel skinLabel_MB_Battery_Result;
        private CCWin.SkinControl.SkinLabel skinLabel24;
        private CCWin.SkinControl.SkinTabPage skinTabPage_MB_STOPTEST;
        private CCWin.SkinControl.SkinSplitContainer skinSplitContainer19;
        private CCWin.SkinControl.SkinLabel skinLabel15;
        private CCWin.SkinControl.SkinLabel MB_TEMP_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel skinLabel21;
        private CCWin.SkinControl.SkinLabel MB_POWER_DOWN_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel skinLabel60;
        private CCWin.SkinControl.SkinLabel MB_BATTERY_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel skinLabel22;
        private CCWin.SkinControl.SkinLabel MB_TEST_START_TIME;
        private CCWin.SkinControl.SkinLabel skinLabel85;
        private CCWin.SkinControl.SkinLabel MB_TEST_USED_TIME_VAL;
        private CCWin.SkinControl.SkinLabel MB_LOCK_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_BT_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_POWER_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_ALL_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_FW_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_TESTOR_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_PCB_RESULT_VAL;
        private CCWin.SkinControl.SkinLabel MB_TEST_USED_TIME;
        private CCWin.SkinControl.SkinLabel MB_FLASH_RESULT;
        private CCWin.SkinControl.SkinLabel MB_LED_RESULT;
        private CCWin.SkinControl.SkinLabel MB_POWER_RESULT;
        private CCWin.SkinControl.SkinLabel MB_ALL_RESULT;
        private CCWin.SkinControl.SkinLabel MB_FW_RESULT;
        private CCWin.SkinControl.SkinLabel MB_TESTOR_RESULT;
        private CCWin.SkinControl.SkinLabel MB_PCB_RESULT;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private CCWin.SkinControl.SkinButton skinButton_MB_Power_Success;
    }
}

